import { BaseSeeder } from '@adonisjs/lucid/seeders'
import User from '#models/user'
import Wallet from '#models/wallet'
import { BaseModel } from '@adonisjs/lucid/orm'

export default class extends BaseSeeder {
  async run() {
    // Vérifier si l'admin existe déjà
    const existingAdmin = await (User as typeof BaseModel).query().where('email', 'sublymus@gmail.com').first() as any
    if (existingAdmin) {
      // Mettre à jour le mot de passe si nécessaire (le hook @beforeSave le hash automatiquement)
      const adminPassword = 'admin123'
      existingAdmin.password = adminPassword // Le hook va hasher automatiquement
      existingAdmin.isActive = true // S'assurer qu'il est actif
      
      // Vérifier si le wallet principal existe
      if (!existingAdmin.mainWalletId) {
        const platformWallet = new Wallet()
        platformWallet.managerId = existingAdmin.id
        platformWallet.ownerId = existingAdmin.id
        platformWallet.ownerName = existingAdmin.name
        platformWallet.ownerWavePhone = '+225 0759020515'
        platformWallet.entityType = 'PLATFORM'
        // Note: balanceAccounting et balanceAvailable sont maintenant calculés dynamiquement
        ;(platformWallet as any)._balanceAccounting = 0
        ;(platformWallet as any)._balanceAvailable = 0
        platformWallet.overdraftLimit = 1000000000
        platformWallet.currency = 'XOF'
        platformWallet.isLocked = false
        await (platformWallet as any).save()
        await platformWallet.calculateBalanceAccounting()
        await platformWallet.calculateBalanceAvailable()
        
        existingAdmin.mainWalletId = platformWallet.id
        console.log(`✅ Wallet principal créé: ${platformWallet.id}`)
      }
      
      await existingAdmin.save()
      console.log('✅ Admin mis à jour')
      return
    }

    // 1. Créer l'admin (le hook @beforeSave hash automatiquement le mot de passe)
    const adminPassword = 'admin123' // À changer en production
    const admin = new User()
    admin.name = 'Admin Sublymus'
    admin.email = 'sublymus@gmail.com'
    admin.password = adminPassword // Le hook @beforeSave va hasher automatiquement
    admin.apiKeyHash = null // Pas de clé API pour l'admin (il utilise access tokens)
    admin.isActive = true
    admin.webhookUrl = null
    admin.website = 'https://sublymus.com'
    await (admin as any).save()

    // 2. Créer le wallet principal de l'admin
    const platformWallet = new Wallet()
    platformWallet.managerId = admin.id
    platformWallet.ownerId = admin.id
    platformWallet.ownerName = admin.name
    platformWallet.ownerWavePhone = '+225 0759020515'
    platformWallet.entityType = 'PLATFORM'
    // Note: balanceAccounting et balanceAvailable sont maintenant calculés dynamiquement
    ;(platformWallet as any)._balanceAccounting = 0
    ;(platformWallet as any)._balanceAvailable = 0
    platformWallet.overdraftLimit = 1000000000 // Marge énorme pour le système
    platformWallet.currency = 'XOF'
    platformWallet.isLocked = false
    await (platformWallet as any).save()
    await platformWallet.calculateBalanceAccounting()
    await platformWallet.calculateBalanceAvailable()

    // 3. Lier le wallet à l'admin
    admin.mainWalletId = platformWallet.id
    await (admin as any).save()

    console.log('------------------------------------------------')
    console.log('🎉 Admin créé avec succès')
    console.log(`Email: ${admin.email}`)
    console.log(`Password: ${adminPassword}`)
    console.log(`User ID: ${admin.id}`)
    console.log(`Wallet ID: ${platformWallet.id}`)
    console.log('------------------------------------------------')
    console.log('⚠️  Changez le mot de passe en production !')
    console.log('------------------------------------------------')
  }
}
