import { BaseSchema } from '@adonisjs/lucid/schema'

export default class extends BaseSchema {
  protected tableName = 'payment_intents'

  async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.string('id').primary()
      table.string('external_reference').notNullable().index()
      table.string('source_system').notNullable()
      table.bigInteger('amount').notNullable()
      table.string('currency', 3).notNullable().defaultTo('XOF')
      table.string('payer_id').nullable()
      table.string('description').nullable()
      table.string('aggregated_merchant_id').nullable()
      table.string('wave_session_id').nullable().index()
      table.string('wave_checkout_url').nullable()
      table
        .enum('status', ['PENDING', 'WAVE_CREATED', 'COMPLETED', 'FAILED'])
        .notNullable()
        .defaultTo('PENDING')
      table.jsonb('splits_config').notNullable()

      table.timestamp('created_at').defaultTo(this.now()).notNullable()
      table.timestamp('updated_at').defaultTo(this.now()).notNullable()
    })
  }

  async down() {
    this.schema.dropTable(this.tableName)
  }
}