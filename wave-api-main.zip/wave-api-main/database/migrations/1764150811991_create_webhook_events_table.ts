import { BaseSchema } from '@adonisjs/lucid/schema'

export default class extends BaseSchema {
  protected tableName = 'webhook_events'

  async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.string('id').primary()
      table.string('wave_event_id').notNullable().unique()
      table.string('type').notNullable()
      table.jsonb('payload').notNullable()
      table.enum('status', ['PENDING', 'PROCESSED', 'FAILED', 'IGNORED']).notNullable().defaultTo('PENDING')
      table.text('processing_error').nullable()

      table.timestamp('created_at').defaultTo(this.now()).notNullable()
      table.timestamp('updated_at').defaultTo(this.now()).notNullable()
    })
  }

  async down() {
    this.schema.dropTable(this.tableName)
  }
}