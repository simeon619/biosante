import { BaseSchema } from '@adonisjs/lucid/schema'

export default class extends BaseSchema {
  protected tableName = 'wallets'

  async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.string('id').primary()
      table
        .string('manager_id')
        .notNullable()
        .references('id')
        .inTable('users')
        .onDelete('CASCADE')
      table.string('owner_id').notNullable()
      table.string('owner_name').nullable()
      table.string('owner_wave_phone').nullable()
      table
        .enum('entity_type', ['DRIVER', 'VENDOR', 'CLIENT', 'PLATFORM'])
        .notNullable()
      table.bigInteger('balance_accounting').notNullable().defaultTo(0)
      table.bigInteger('balance_available').notNullable().defaultTo(0)
      table.bigInteger('overdraft_limit').notNullable().defaultTo(0)
      table.string('currency', 3).notNullable().defaultTo('XOF')
      table.boolean('is_locked').defaultTo(false)

      table.timestamp('created_at').defaultTo(this.now()).notNullable()
      table.timestamp('updated_at').defaultTo(this.now()).notNullable()
    })
  }

  async down() {
    this.schema.dropTable(this.tableName)
  }
}