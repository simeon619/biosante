import { BaseSchema } from '@adonisjs/lucid/schema'

export default class extends BaseSchema {
  protected tableName = 'ledger_entries'

  async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.string('id').primary()
      table
        .string('wallet_id')
        .notNullable()
        .references('id')
        .inTable('wallets')
        .onDelete('CASCADE')
      table.string('transaction_group_id').notNullable()
      table.bigInteger('amount').notNullable()
      table.enum('direction', ['CREDIT', 'DEBIT']).notNullable()
      table
        .enum('category', [
          'ORDER_PAYMENT',
          'SERVICE_PAYMENT',
          'COMMISSION',
          'DEPOSIT',
          'PAYOUT',
          'REFUND',
          'ADJUSTMENT',
          'SUBSCRIPTION',
        ])
        .notNullable()
      table.string('label').notNullable()
      table.string('source_system').notNullable()
      table.string('external_reference').notNullable()
      table.jsonb('metadata').defaultTo('{}')
      table.enum('funds_status', ['ON_HOLD', 'AVAILABLE', 'LOCKED', 'FAILED', 'CANCELED', 'REFUNDED']).notNullable()
      table.timestamp('release_scheduled_at').nullable()
      table.timestamp('released_at').nullable()

      table.timestamp('created_at').defaultTo(this.now()).notNullable()
      table.timestamp('updated_at').defaultTo(this.now()).notNullable()
    })
  }

  async down() {
    this.schema.dropTable(this.tableName)
  }
}