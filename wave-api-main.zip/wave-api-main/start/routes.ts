/*
|--------------------------------------------------------------------------
| Routes file
|
| The routes file is used for defining the HTTP routes.
|
*/

import router from '@adonisjs/core/services/router'
import { middleware } from '#start/kernel'

// Lazy Loading des Contrôleurs
const PaymentsController = () => import('#controllers/payments_controller')
const WalletsController = () => import('#controllers/wallets_controller')
const TransactionsController = () => import('#controllers/transactions_controller')
const PayoutsController = () => import('#controllers/payouts_controller')
const WebhooksController = () => import('#controllers/webhooks_controller')
const AdminController = () => import('#controllers/admin_controller')
const TestEventsController = () => import('#controllers/test_events_controller')
const AuthController = () => import('#controllers/auth_controller')

// --------------------------------------------------------
// 🌍 ROUTES PUBLIQUES
// --------------------------------------------------------

router.get('/', async () => {
  return { status: 'ok', service: 'Sublymus Wallet API' }
})

// Auth (Login admin uniquement)
router.post('/v1/auth/login', [AuthController, 'login'])

// Webhook Wave (Protégé par signature crypto, pas par Auth Bearer)
// IMPORTANT: Cette route doit être en dehors du body parser pour pouvoir lire le raw body
router.post('/webhook/wave', [WebhooksController, 'handle']).use([]) // Pas de body parser pour cette route

// --------------------------------------------------------
// 🔒 ROUTES PRIVÉES (API Serveur-à-Serveur)
// --------------------------------------------------------
// Ces routes nécessitent : Authorization: Bearer <API_KEY> + X-Manager-Id

router
  .group(() => {
    // --- GESTION DES PAIEMENTS (Encaissement) ---
    router.post('/checkout/complex', [PaymentsController, 'initialize'])

    // --- GESTION DES WALLETS ---
    router.post('/wallets', [WalletsController, 'create'])
    router.get('/wallets/main', [WalletsController, 'showMain']) // Le wallet principal du Manager
    router.get('/wallets/:id', [WalletsController, 'show']) // Un wallet spécifique (Livreur/Vendeur)
    router.post('/wallets/deposit', [WalletsController, 'deposit']) // Recharger un wallet (utilisateur)

    // --- GESTION DES RETRAITS (Payouts) ---
    router.post('/payouts', [PayoutsController, 'create'])

    // --- TRANSACTIONS INTERNES ---
    router.post('/transactions/transfer', [TransactionsController, 'transfer'])
    router.post('/transactions/release', [TransactionsController, 'release'])
    router.post('/transactions/refund', [TransactionsController, 'refund'])

  })
  .prefix('/v1')
  .use(middleware.serverAuth()) // 🛡️ Activation du Middleware de sécurité serveur-à-serveur

// --------------------------------------------------------
// 🔐 ROUTES ADMIN (Access Tokens)
// --------------------------------------------------------
// Ces routes nécessitent : Authorization: Bearer <ACCESS_TOKEN> (généré via /v1/auth/login)

router
  .group(() => {
    router.get('/stats', [AdminController, 'stats']) // KPIs (legacy)
    router.get('/global-stats', [AdminController, 'globalStats']) // KPIs globaux avec compteurs
    router.get('/wave-balance', [AdminController, 'waveBalance']) // Solde du compte Wave
    router.get('/users/:id/stats', [AdminController, 'userStats']) // Stats d'un user
    router.get('/wallets/:id/stats', [AdminController, 'walletStats']) // Stats d'un wallet
    router.get('/ledgers', [AdminController, 'ledgers']) // Grand Livre
    router.get('/intents', [AdminController, 'intents']) // Paiements
    router.post('/intents', [AdminController, 'createIntent']) // Créer un payment intent
    router.get('/wallets', [AdminController, 'wallets']) // Comptes
    router.post('/wallets', [AdminController, 'createWallet']) // Créer un wallet
    router.post('/wallets/deposit', [AdminController, 'depositWallet']) // Recharger un wallet (admin)
    router.get('/users', [AdminController, 'users']) // Managers
    router.post('/users', [AdminController, 'createUser']) // Créer un manager
    router.post('/users/generate-api-key', [AdminController, 'generateApiKey']) // Générer une API key
    router.post('/users/revoke-api-key', [AdminController, 'revokeApiKey']) // Révoquer une API key
    router.get('/users/:id/api-key-status', [AdminController, 'checkApiKey']) // Vérifier le statut de l'API key
    router.get('/webhooks', [AdminController, 'webhooks']) // Logs
    router.post('/payouts', [AdminController, 'createPayout']) // Créer un payout
    router.post('/wallets/transfer', [AdminController, 'transferWallet']) // Transfert interne (admin)
    router.post('/transactions/release', [AdminController, 'release']) // Release (admin - peut libérer LOCKED)
    router.post('/transactions/refund', [AdminController, 'refund']) // Refund (admin)
    router.post('/events/test', [TestEventsController, 'trigger']) // Emission d'événements de test depuis serveur HTTP
    router.post('/events/test-worker', [TestEventsController, 'triggerWorker']) // Emission d'événements de test simulant worker
  })
  .prefix('/v1/admin')
  .use(middleware.auth({ guards: ['api'] })) // Auth par access token pour admin
