import transmit from '@adonisjs/transmit/services/main'

/**
 * Register Transmit routes for both admin and manager contexts.
 * Updated: 2025-11-28 : ok
 */
transmit.registerRoutes((route) => {
  route.prefix('/v1/admin')
})

transmit.registerRoutes((route) => {
  route.prefix('/v1')
})

