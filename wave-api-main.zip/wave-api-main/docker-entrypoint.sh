#!/bin/sh
# docker-entrypoint.sh pour wave_api

set -e 

echo "[wave_api Entrypoint] Démarrage du conteneur Wave API"
echo "[wave_api Entrypoint] NODE_ENV: ${NODE_ENV}"

# Vérifier que les variables d'environnement essentielles pour la BDD sont là
if [ -z "$DB_HOST" ] || [ -z "$DB_USER" ] || [ -z "$DB_PASSWORD" ] || [ -z "$DB_DATABASE" ]; then
    echo "[wave_api Entrypoint] ERREUR: Variables d'environnement pour la base de données manquantes."
    echo "DB_HOST: $DB_HOST, DB_USER: $DB_USER, DB_DATABASE: $DB_DATABASE"
    # DB_PASSWORD n'est pas affiché pour la sécurité
    exit 1
fi

# Vérifier les variables Wave essentielles
if [ -z "$WAVE_API_KEY" ] || [ -z "$WAVE_WEBHOOK_SECRET" ]; then
    echo "[wave_api Entrypoint] ERREUR: Variables d'environnement Wave manquantes."
    echo "WAVE_API_KEY: ${WAVE_API_KEY:+défini}, WAVE_WEBHOOK_SECRET: ${WAVE_WEBHOOK_SECRET:+défini}"
    exit 1
fi

echo "[wave_api Entrypoint] Attente de la disponibilité de la base de données (${DB_HOST}:${DB_PORT:-5432})..."

# Attendre que la base de données soit disponible (optionnel, peut être géré par Swarm healthcheck)
# On peut utiliser une boucle simple ou un outil comme wait-for-it
# Pour l'instant, on fait confiance à Swarm pour gérer les dépendances

# Exécuter les migrations de la base de données
# --force est important en production pour ne pas demander de confirmation interactive
echo "[wave_api Entrypoint] Exécution des migrations de la base de données..."
node ace migration:run --force

if [ $? -eq 0 ]; then
    echo "[wave_api Entrypoint] Migrations exécutées avec succès (ou aucune migration à exécuter)."
else
    echo "[wave_api Entrypoint] ERREUR lors de l'exécution des migrations."
    exit 1
fi

# Lancer la commande principale passée au conteneur (CMD dans Dockerfile ou surchargée par Swarm)
echo "[wave_api Entrypoint] Démarrage du serveur d'application (commande: $@)..."
exec "$@"

