import type { HttpContext } from '@adonisjs/core/http'
import vine from '@vinejs/vine'
import paymentOrchestrator from '#services/payment_orchestrator_service'

export default class PaymentsController {
  public async initialize({ request, response }: HttpContext) {
    const schema = vine.object({
      amount: vine.number().withoutDecimals().min(1),
      currency: vine.string().fixedLength(3),
      external_reference: vine.string(),
      source_system: vine.string(),
      aggregated_merchant_id: vine.string().optional(),
      payer_id: vine.string().optional(),
      description: vine.string().optional(),
      success_url: vine.string().url(),
      error_url: vine.string().url(),
      splits: vine
        .array(
          vine.object({
            wallet_id: vine.string(),
            amount: vine.number().withoutDecimals().min(1),
            category: vine.string(),
            label: vine.string(),
            external_reference: vine.string().optional(),
            release_delay_hours: vine.number().min(0).optional(),
            allow_early_release: vine.boolean().optional(),
          })
        )
        .minLength(1),
    })

    const payload = await request.validateUsing(vine.compile(schema))

    const intent = await paymentOrchestrator.initializeIntent({
      amount: payload.amount,
      currency: payload.currency,
      externalReference: payload.external_reference,
      sourceSystem: payload.source_system,
      aggregatedMerchantId: payload.aggregated_merchant_id,
      payerId: payload.payer_id,
      description: payload.description,
      successUrl: payload.success_url,
      errorUrl: payload.error_url,
      splits: payload.splits as any,
    })

    return response.created({
      message: 'Payment Intent created successfully',
      data: {
        payment_intent_id: intent.id,
        status: intent.status,
        wave_checkout_url: intent.waveCheckoutUrl,
        amount: intent.amount,
        currency: intent.currency,
        external_reference: intent.externalReference,
      },
    })
  }
}

