import type { HttpContext } from '@adonisjs/core/http'
import webhookProcessor from '#services/webhook_processor_service'
import queueService from '#services/queue_service'
import logger from '@adonisjs/core/services/logger'

export default class WebhooksController {
  public async handle({ request, response }: HttpContext) {
    logger.info('[WebhookController] ===== DEBUT TRAITEMENT WEBHOOK =====')
    
    // Étape 1: Récupération de la signature (Wave utilise 'Wave-Signature' avec majuscule)
    const signature = request.header('Wave-Signature') || request.header('wave-signature')
    logger.info({ signature: signature ? `${signature.substring(0, 50)}...` : null }, '[WebhookController] Étape 1: Signature header récupéré')
    
    if (!signature) {
      logger.warn('[WebhookController] Étape 1: Signature manquante - REJET')
      return response.unauthorized('Signature manquante')
    }

    // Étape 2: Récupération du raw body
    logger.info('[WebhookController] Étape 2: Récupération du raw body')
    
    // Essayer d'abord le raw body capturé par le middleware
    let rawBody = (request as any)._rawBody
    logger.info({ hasCapturedRawBody: !!rawBody, capturedRawBodyLength: rawBody?.length }, '[WebhookController] Étape 2: Raw body depuis middleware')
    
    // Si pas disponible, essayer request.raw()
    if (!rawBody) {
      rawBody = request.raw()
      logger.info({ hasRawBody: !!rawBody, rawBodyType: typeof rawBody }, '[WebhookController] Étape 2: request.raw() résultat')
    }
    
    // Si toujours pas disponible, lire depuis le stream Node.js natif
    if (!rawBody) {
      try {
        const nodeRequest = (request as any).request || (request as any).req
        if (nodeRequest) {
          const chunks: Buffer[] = []
          if (nodeRequest.readable) {
            for await (const chunk of nodeRequest) {
              chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk))
            }
            rawBody = Buffer.concat(chunks).toString('utf-8')
            logger.info({ rawBodyLength: rawBody.length }, '[WebhookController] Étape 2: Raw body lu depuis stream Node.js')
          }
        }
      } catch (error) {
        logger.warn({ err: error }, '[WebhookController] Étape 2: Erreur lors de la lecture du stream')
      }
    }
    
    // Si toujours pas disponible, utiliser JSON.stringify (moins fiable pour la crypto)
    if (!rawBody) {
      logger.warn('[WebhookController] Étape 2: Aucun raw body disponible, utilisation de JSON.stringify (peut causer des problèmes de signature)')
      const body = request.body()
      rawBody = JSON.stringify(body)
      logger.info({ bodyKeys: Object.keys(body || {}), rawBodyLength: rawBody.length }, '[WebhookController] Étape 2: Body stringifié')
    } else {
      logger.info({ rawBodyLength: rawBody.length, rawBodyPreview: rawBody.substring(0, 100) }, '[WebhookController] Étape 2: Raw body disponible')
    }
    
    // Parser le body depuis le raw body pour l'utiliser ensuite
    let payload: any
    try {
      payload = JSON.parse(rawBody)
      logger.info({ payloadKeys: Object.keys(payload || {}) }, '[WebhookController] Étape 2: Payload parsé depuis raw body')
    } catch (error) {
      // Si le parsing échoue, utiliser request.body() en fallback
      payload = request.body()
      logger.warn({ err: error }, '[WebhookController] Étape 2: Erreur lors du parsing, utilisation de request.body()')
    }
    
    // Étape 3: Vérification de la signature
    logger.info({ rawBodyLength: rawBody.length, signatureLength: signature.length, signaturePreview: signature.substring(0, 30) }, '[WebhookController] Étape 3: Vérification de la signature')
    
    const signatureValid = webhookProcessor.verifySignature(rawBody, signature)
    logger.info({ signatureValid }, '[WebhookController] Étape 3: Résultat de la vérification de signature')
    
    if (!signatureValid) {
      logger.warn({ rawBodyLength: rawBody.length, signatureLength: signature.length }, '[WebhookController] Étape 3: Signature invalide - REJET')
      return response.unauthorized('Signature invalide')
    }

    logger.info('[WebhookController] Étape 3: Signature valide - CONTINUATION')

    // Étape 4: Extraction du payload (déjà parsé à l'étape 2)
    logger.info('[WebhookController] Étape 4: Extraction du payload')
    const waveEventId = payload.id
    const type = payload.type
    logger.info({ waveEventId, type, payloadKeys: Object.keys(payload || {}) }, '[WebhookController] Étape 4: Payload extrait')

    if (!waveEventId || !type) {
      logger.warn({ waveEventId, type }, '[WebhookController] Étape 4: Payload incomplet - REJET')
      return response.badRequest({ message: 'Payload incomplet' })
    }

    // Étape 5: Ajout à la queue
    logger.info({ waveEventId, type }, '[WebhookController] Étape 5: Ajout du job à la queue')
    try {
      const job = await queueService.addJob(
        'wave-webhooks',
        'process',
        {
          waveEventId,
          type,
          payload,
        },
        {
          removeOnComplete: true,
          attempts: 5,
          backoff: { type: 'exponential', delay: 1000 },
        }
      )
      logger.info({ jobId: job?.id }, '[WebhookController] Étape 5: Job ajouté avec succès')
    } catch (error) {
      logger.error({ err: error, waveEventId, type }, '[WebhookController] Étape 5: Erreur lors de l\'ajout à la queue')
      return response.status(500).send('Queue error')
    }

    logger.info({ waveEventId, type }, '[WebhookController] ===== FIN TRAITEMENT WEBHOOK - SUCCÈS =====')
    return response.ok({ status: 'ACK' })
  }
}

