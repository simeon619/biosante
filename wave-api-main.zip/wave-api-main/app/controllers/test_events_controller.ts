import type { HttpContext } from '@adonisjs/core/http'
import eventBus from '#services/event_bus'
import logger from '@adonisjs/core/services/logger'

export default class TestEventsController {
  /**
   * Test SSE depuis le serveur HTTP
   * Émet 10 événements test.tick avec un délai de 500ms entre chaque
   */
  public async trigger({ response }: HttpContext) {
    logger.info('[TestEventsController] Début test SSE depuis serveur HTTP')
    
    for (let i = 1; i <= 10; i++) {
      eventBus.emitEvent({
        type: 'test.tick',
        referenceId: `test-http-${Date.now()}-${i}`,
        scopes: ['admin'],
        payload: {
          counter: i,
          source: 'http-server',
          timestamp: new Date().toISOString(),
        },
      })
      await new Promise((resolve) => setTimeout(resolve, 500))
    }

    logger.info('[TestEventsController] Fin test SSE depuis serveur HTTP')
    return response.ok({ message: 'Test SSE events emitted from HTTP server', count: 10 })
  }

  /**
   * Test SSE simulant une émission depuis le worker
   * Émet 10 événements test.worker avec un délai de 500ms entre chaque
   * Simule le comportement du worker qui émet des événements via EventBus
   */
  public async triggerWorker({ response }: HttpContext) {
    logger.info('[TestEventsController] Début test SSE simulant worker')
    
    for (let i = 1; i <= 10; i++) {
      eventBus.emitEvent({
        type: 'test.worker',
        referenceId: `test-worker-${Date.now()}-${i}`,
        scopes: ['admin'],
        payload: {
          counter: i,
          source: 'worker-simulated',
          timestamp: new Date().toISOString(),
        },
      })
      await new Promise((resolve) => setTimeout(resolve, 500))
    }

    logger.info('[TestEventsController] Fin test SSE simulant worker')
    return response.ok({ message: 'Test SSE events emitted from worker simulation', count: 10 })
  }
}

