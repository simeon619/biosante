import type { HttpContext } from '@adonisjs/core/http'
import vine from '@vinejs/vine'
import Wallet from '#models/wallet'
import User from '#models/user'
import paymentOrchestrator from '#services/payment_orchestrator_service'

export default class WalletsController {
  private getManagerId(request: HttpContext['request']) {
    const managerId = request.header('x-manager-id')
    if (!managerId) {
      throw new Error('X-Manager-Id header is required')
    }
    return managerId
  }

  private async getManager(request: HttpContext['request']): Promise<User> {
    const managerId = this.getManagerId(request)
    const manager = await User.find(managerId)
    if (!manager || !manager.isActive) {
      throw new Error('Manager not found or inactive')
    }
    return manager
  }

  public async create({ request, response }: HttpContext) {
    const schema = vine.object({
      owner_id: vine.string(),
      owner_name: vine.string().optional(),
      owner_wave_phone: vine.string().optional(),
      entity_type: vine.enum(['DRIVER', 'VENDOR', 'CLIENT', 'PLATFORM'] as const),
      currency: vine.string().fixedLength(3),
      overdraft_limit: vine.number().withoutDecimals().min(0).optional(),
    })

    const payload = await request.validateUsing(vine.compile(schema))
    const managerId = this.getManagerId(request)

    // Valider le format du numéro de téléphone si fourni
    const phoneRegex = /^\+\d{1,4} \d{6,15}$/
    if (payload.owner_wave_phone && !phoneRegex.test(payload.owner_wave_phone)) {
      return response.badRequest({ message: 'owner_wave_phone must be in format "+indicatif espace numéro" (e.g., "+225 0759020515")' })
    }

    const wallet = new Wallet()
    wallet.ownerId = payload.owner_id
    wallet.ownerName = payload.owner_name || null
    wallet.ownerWavePhone = payload.owner_wave_phone || null
    wallet.entityType = payload.entity_type
    wallet.currency = payload.currency
    wallet.overdraftLimit = payload.overdraft_limit ?? 0
    // Note: balanceAccounting et balanceAvailable sont maintenant calculés dynamiquement
    // On les initialise à 0 pour satisfaire la contrainte NOT NULL en base
    ;(wallet as any)._balanceAccounting = 0
    ;(wallet as any)._balanceAvailable = 0
    wallet.managerId = managerId
    await wallet.save()
    
    // Calculer les soldes après la création (sera 0 car pas encore de ledger entries)
    await wallet.calculateBalanceAccounting()
    await wallet.calculateBalanceAvailable()

    return response.created(wallet)
  }

  public async showMain({ request, response }: HttpContext) {
    const managerId = this.getManagerId(request)
    const wallet = await Wallet.query().where('manager_id', managerId).andWhere('entity_type', 'PLATFORM').first()
    if (!wallet) {
      return response.notFound({ message: 'Main wallet not found' })
    }
    return wallet
  }

  public async show({ request, response }: HttpContext) {
    const managerId = this.getManagerId(request)
    const wallet = await Wallet.query().where('manager_id', managerId).andWhere('id', request.param('id')).first()
    if (!wallet) {
      return response.notFound({ message: 'Wallet not found' })
    }
    return wallet
  }

  /**
   * Rechargement direct d'un wallet par un utilisateur
   * L'utilisateur peut recharger son wallet principal ou un wallet de son manager
   */
  public async deposit({ request, response }: HttpContext) {
    const { wallet_id, amount, currency = 'XOF', description, success_url, error_url } = request.only([
      'wallet_id',
      'amount',
      'currency',
      'description',
      'success_url',
      'error_url',
    ])
    
    if (!amount || !success_url || !error_url) {
      return response.badRequest({ message: 'amount, success_url, and error_url are required' })
    }
    
    if (Number(amount) < 1 || !Number.isInteger(Number(amount))) {
      return response.badRequest({ message: 'amount must be a positive integer' })
    }
    
    if (currency && currency.length !== 3) {
      return response.badRequest({ message: 'currency must be 3 characters' })
    }
    const manager = await this.getManager(request)

    // Déterminer le wallet à recharger
    let targetWallet: Wallet | null = null
    if (wallet_id) {
      // Vérifier que le wallet appartient au manager
      targetWallet = await Wallet.query()
        .where('id', wallet_id)
        .where('manager_id', manager.id)
        .first()
      if (!targetWallet) {
        return response.notFound({ message: 'Wallet not found or does not belong to your manager' })
      }
    } else {
      // Utiliser le wallet principal du manager
      if (!manager.mainWalletId) {
        return response.badRequest({ message: 'Manager has no main wallet' })
      }
      targetWallet = await Wallet.find(manager.mainWalletId)
      if (!targetWallet) {
        return response.notFound({ message: 'Main wallet not found' })
      }
    }

    if (targetWallet.isLocked) {
      return response.badRequest({ message: 'Wallet is locked' })
    }

    // Créer un PaymentIntent avec un seul split vers le wallet cible
    // Catégorie DEPOSIT, fundsStatus AVAILABLE (pas de délai pour rechargement)
    const intent = await paymentOrchestrator.initializeIntent({
      amount: Number(amount),
      currency: currency || 'XOF',
      externalReference: `deposit_${targetWallet.id}_${Date.now()}`,
      sourceSystem: 'INTERNAL',
      payerId: manager.id,
      description: description || `Rechargement wallet ${targetWallet.id}`,
      successUrl: success_url,
      errorUrl: error_url,
      splits: [
        {
          wallet_id: targetWallet.id,
          amount: Number(amount),
          category: 'DEPOSIT',
          label: description || `Rechargement compte`,
          release_delay_hours: 0, // Disponible immédiatement
          allow_early_release: false,
        },
      ],
    })

    return response.created({
      message: 'Deposit intent created successfully',
      data: {
        payment_intent_id: intent.id,
        wallet_id: targetWallet.id,
        wallet_owner: targetWallet.ownerName || targetWallet.ownerId,
        status: intent.status,
        wave_checkout_url: intent.waveCheckoutUrl,
        amount: intent.amount,
        currency: intent.currency,
      },
    })
  }
}

