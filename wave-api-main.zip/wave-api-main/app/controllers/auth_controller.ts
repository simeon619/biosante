import type { HttpContext } from '@adonisjs/core/http'
import User from '#models/user'
import { isAdminEmail } from '#constants/admin_emails'
import hash from '@adonisjs/core/services/hash'

export default class AuthController {
  public async login({ request, response }: HttpContext) {
    const { email, password } = request.only(['email', 'password'])

    if (!email || !password) {
      return response.badRequest({ message: 'Email and password are required' })
    }

    // Vérifier que c'est un admin
    if (!isAdminEmail(email)) {
      return response.unauthorized({ message: 'Access denied' })
    }

    // Trouver l'utilisateur
    const user = await User.findBy('email', email)
    if (!user || !user.isActive) {
      return response.unauthorized({ message: 'Invalid credentials' })
    }

    // Vérifier le mot de passe directement avec hash.verify
    const isValid = await hash.verify(user.password, password)
    if (!isValid) {
      return response.unauthorized({ message: 'Invalid credentials' })
    }

    // Générer un access token
    const token = await User.accessTokens.create(user)

    return response.ok({
      token: token.value!.release(),
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
      },
    })
  }
}

