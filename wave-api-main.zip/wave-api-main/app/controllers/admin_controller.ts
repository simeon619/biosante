import type { HttpContext } from '@adonisjs/core/http'
import { isAdminEmail } from '#constants/admin_emails'
import User from '#models/user'
import vine from '@vinejs/vine'
import adminService from '#services/admin_service'
import releaseService from '#services/release_service'

export default class AdminController {
  private assertAdmin(user: User | undefined) {
    if (!user || !isAdminEmail(user.email)) {
      throw new Error('ACCESS_DENIED')
    }
  }

  private getUser(request: HttpContext['request'], auth: HttpContext['auth']) {
    // Essayer d'abord via auth (access token)
    const user = auth.user as User | undefined
    if (user) return user
    // Fallback sur request.user (serverAuth)
    return (request as any).user as User | undefined
  }

  public async stats({ request, response, auth }: HttpContext) {
    this.assertAdmin(this.getUser(request, auth))
    const { start_date, end_date, wallet_id, manager_id } = request.qs()

    try {
      const result = await adminService.getStats({ start_date, end_date, wallet_id, manager_id })
      return response.ok(result)
    } catch (error: any) {
      return response.internalServerError({ message: 'Failed to get stats', error: error.message })
    }
  }

  public async ledgers({ request, response, auth }: HttpContext) {
    this.assertAdmin(this.getUser(request, auth))
    const { page = 1, limit = 20, ...filters } = request.qs()

    try {
      const result = await adminService.getLedgers(filters, Number(page), Number(limit))
      return response.ok(result)
    } catch (error: any) {
      return response.internalServerError({ message: 'Failed to get ledgers', error: error.message })
    }
  }

  public async intents({ request, response, auth }: HttpContext) {
    this.assertAdmin(this.getUser(request, auth))
    const { page = 1, limit = 20, ...filters } = request.qs()

    try {
      const result = await adminService.getIntents(filters, Number(page), Number(limit))
      return response.ok(result)
    } catch (error: any) {
      return response.internalServerError({ message: 'Failed to get intents', error: error.message })
    }
  }

  public async wallets({ request, response, auth }: HttpContext) {
    this.assertAdmin(this.getUser(request, auth))
    const { page = 1, limit = 20, ...filters } = request.qs()

    try {
      const result = await adminService.getWallets(filters, Number(page), Number(limit))
      return response.ok(result)
    } catch (error: any) {
      return response.internalServerError({ message: 'Failed to get wallets', error: error.message })
    }
  }

  public async users({ request, response, auth }: HttpContext) {
    this.assertAdmin(this.getUser(request, auth))
    const { page = 1, limit = 20, ...filters } = request.qs()

    try {
      const result = await adminService.getUsers(filters, Number(page), Number(limit))
      return response.ok(result)
    } catch (error: any) {
      return response.internalServerError({ message: 'Failed to get users', error: error.message })
    }
  }

  public async createUser({ request, response, auth }: HttpContext) {
    this.assertAdmin(this.getUser(request, auth))
    
    const { name, email, password, website } = request.only(['name', 'email', 'password', 'website'])
    
    if (!email || !password) {
      return response.badRequest({ message: 'Email and password are required' })
    }

    try {
      const result = await adminService.createUser({ name, email, password, website })
      return response.created(result)
    } catch (error: any) {
      if (error.message === 'Email already exists') {
        return response.badRequest({ message: error.message })
      }
      return response.internalServerError({ message: 'Failed to create user', error: error.message })
    }
  }

  public async createWallet({ request, response, auth }: HttpContext) {
    this.assertAdmin(this.getUser(request, auth))
    
    const { manager_id, owner_id, owner_name, owner_wave_phone, entity_type, currency, overdraft_limit } = request.only([
      'manager_id',
      'owner_id',
      'owner_name',
      'owner_wave_phone',
      'entity_type',
      'currency',
      'overdraft_limit',
    ])
    
    if (!manager_id || !owner_id || !entity_type) {
      return response.badRequest({ message: 'manager_id, owner_id, and entity_type are required' })
    }

    try {
      const result = await adminService.createWallet({
        manager_id,
        owner_id,
        owner_name,
        owner_wave_phone,
        entity_type: entity_type as 'DRIVER' | 'VENDOR' | 'CLIENT' | 'PLATFORM',
        currency,
        overdraft_limit,
      })
      return response.created(result)
    } catch (error: any) {
      if (error.message.includes('not found') || error.message.includes('must be')) {
        return response.badRequest({ message: error.message })
      }
      return response.internalServerError({ 
        message: 'Failed to create wallet', 
        error: error.message 
      })
    }
  }

  public async createIntent({ request, response, auth }: HttpContext) {
    this.assertAdmin(this.getUser(request, auth))

    const schema = vine.object({
      amount: vine.number().withoutDecimals().min(1),
      currency: vine.string().fixedLength(3),
      external_reference: vine.string(),
      source_system: vine.string(),
      payer_id: vine.string().optional(),
      description: vine.string().optional(),
      success_url: vine.string().trim(),
      error_url: vine.string().trim(),
      aggregated_merchant_id: vine.string().optional(),
      splits: vine
        .array(
          vine.object({
            wallet_id: vine.string(),
            amount: vine.number().withoutDecimals().min(1),
            category: vine.enum([
              'ORDER_PAYMENT',
              'SERVICE_PAYMENT',
              'COMMISSION',
              'DEPOSIT',
              'PAYOUT',
              'REFUND',
              'ADJUSTMENT',
              'SUBSCRIPTION',
            ] as const),
            label: vine.string(),
            external_reference: vine.string().optional(),
            release_delay_hours: vine.number().min(0).optional(),
            allow_early_release: vine.boolean().optional(),
          })
        )
        .minLength(1),
    })

    const validator = vine.compile(schema)
    const payload = await validator.validate(request.body())

    try {
      const result = await adminService.createIntent(payload)
      return response.created(result)
    } catch (error: any) {
      return response.internalServerError({
        message: 'Failed to create payment intent',
        error: error.message,
      })
    }
  }

  public async waveBalance({ request, response, auth }: HttpContext) {
    this.assertAdmin(this.getUser(request, auth))
    try {
      const balance = await adminService.getWaveBalance()
      return response.ok(balance)
    } catch (error: any) {
      return response.internalServerError({ 
        message: 'Failed to fetch Wave balance', 
        error: error.message 
      })
    }
  }

  public async webhooks({ request, response, auth }: HttpContext) {
    this.assertAdmin(this.getUser(request, auth))
    const { page = 1, limit = 20, ...filters } = request.qs()

    try {
      const result = await adminService.getWebhooks(filters, Number(page), Number(limit))
      return response.ok(result)
    } catch (error: any) {
      return response.internalServerError({ message: 'Failed to get webhooks', error: error.message })
    }
  }

  public async userStats({ request, response, auth }: HttpContext) {
    this.assertAdmin(this.getUser(request, auth))
    const userId = request.param('id')
    const { start_date, end_date } = request.qs()

    try {
      const result = await adminService.getUserStats(userId, { start_date, end_date })
      return response.ok(result)
    } catch (error: any) {
      return response.internalServerError({ message: 'Failed to get user stats', error: error.message })
    }
  }

  public async walletStats({ request, response, auth }: HttpContext) {
    this.assertAdmin(this.getUser(request, auth))
    const walletId = request.param('id')
    const { start_date, end_date } = request.qs()

    try {
      const result = await adminService.getWalletStats(walletId, { start_date, end_date })
      return response.ok(result)
    } catch (error: any) {
      return response.internalServerError({ message: 'Failed to get wallet stats', error: error.message })
    }
  }

  public async globalStats({ request, response, auth }: HttpContext) {
    this.assertAdmin(this.getUser(request, auth))
    const { start_date, end_date } = request.qs()

    try {
      const result = await adminService.getGlobalStats({ start_date, end_date })
      return response.ok(result)
    } catch (error: any) {
      return response.internalServerError({ message: 'Failed to get global stats', error: error.message })
    }
  }

  /**
   * Génère une API key pour un utilisateur (admin uniquement)
   * Retourne l'API key en clair (à sauvegarder immédiatement)
   */
  public async generateApiKey({ request, response, auth }: HttpContext) {
    this.assertAdmin(this.getUser(request, auth))
    
    const { user_id } = request.only(['user_id'])
    
    if (!user_id) {
      return response.badRequest({ message: 'user_id is required' })
    }

    try {
      const result = await adminService.generateApiKey(user_id)
      return response.ok(result)
    } catch (error: any) {
      if (error.message === 'User not found') {
        return response.badRequest({ message: error.message })
      }
      return response.internalServerError({ message: 'Failed to generate API key', error: error.message })
    }
  }

  /**
   * Révoque l'API key d'un utilisateur (admin uniquement)
   * Met apiKeyHash à null
   */
  public async revokeApiKey({ request, response, auth }: HttpContext) {
    this.assertAdmin(this.getUser(request, auth))
    
    const { user_id } = request.only(['user_id'])
    
    if (!user_id) {
      return response.badRequest({ message: 'user_id is required' })
    }

    try {
      const result = await adminService.revokeApiKey(user_id)
      return response.ok(result)
    } catch (error: any) {
      if (error.message === 'User not found') {
        return response.badRequest({ message: error.message })
      }
      return response.internalServerError({ message: 'Failed to revoke API key', error: error.message })
    }
  }

  /**
   * Vérifie si un utilisateur a une API key active (admin uniquement)
   */
  public async checkApiKey({ request, response, auth }: HttpContext) {
    this.assertAdmin(this.getUser(request, auth))
    
    const userId = request.param('id')
    
    if (!userId) {
      return response.badRequest({ message: 'User ID is required' })
    }

    try {
      const result = await adminService.checkApiKey(userId)
      return response.ok(result)
    } catch (error: any) {
      if (error.message === 'User not found') {
        return response.badRequest({ message: error.message })
      }
      return response.internalServerError({ message: 'Failed to check API key', error: error.message })
    }
  }

  /**
   * Rechargement direct d'un wallet par un admin
   * Permet de recharger n'importe quel wallet, y compris le master wallet (PLATFORM)
   */
  public async depositWallet({ request, response, auth }: HttpContext) {
    this.assertAdmin(this.getUser(request, auth))
    
    const { wallet_id, amount, currency = 'XOF', description, success_url, error_url } = request.only([
      'wallet_id',
      'amount',
      'currency',
      'description',
      'success_url',
      'error_url',
    ])
    
    if (!wallet_id || !amount || !success_url || !error_url) {
      return response.badRequest({ message: 'wallet_id, amount, success_url, and error_url are required' })
    }
    
    if (Number(amount) < 1 || !Number.isInteger(Number(amount))) {
      return response.badRequest({ message: 'amount must be a positive integer' })
    }
    
    if (currency && currency.length !== 3) {
      return response.badRequest({ message: 'currency must be 3 characters' })
    }

    try {
      const result = await adminService.depositWallet({
        wallet_id,
        amount: Number(amount),
        currency,
        description,
        success_url,
        error_url,
      })
      return response.created(result)
    } catch (error: any) {
      if (error.message.includes('not found') || error.message.includes('locked')) {
        return response.badRequest({ message: error.message })
      }
      return response.internalServerError({ message: 'Failed to deposit wallet', error: error.message })
    }
  }

  /**
   * Transfert interne (Wallet-to-Wallet) - Admin
   * Permet de transférer entre n'importe quels wallets (pas de restriction manager)
   */
  public async transferWallet({ request, response, auth }: HttpContext) {
    this.assertAdmin(this.getUser(request, auth))
    
    const { from_wallet_id, to_wallet_id, amount, label, category, external_reference } = request.only([
      'from_wallet_id',
      'to_wallet_id',
      'amount',
      'label',
      'category',
      'external_reference',
    ])
    
    if (!from_wallet_id || !to_wallet_id || !amount || !label) {
      return response.badRequest({ message: 'from_wallet_id, to_wallet_id, amount, and label are required' })
    }
    
    if (Number(amount) < 1 || !Number.isInteger(Number(amount))) {
      return response.badRequest({ message: 'amount must be a positive integer' })
    }

    try {
      const result = await adminService.transferWallet({
        from_wallet_id,
        to_wallet_id,
        amount: Number(amount),
        label,
        category,
        external_reference,
      })
      return response.created(result)
    } catch (error: any) {
      if (error.message.includes('not found')) {
        return response.notFound({ message: 'Wallet non trouvé' })
      }
      return response.badRequest({ message: error.message || 'Erreur lors du transfert' })
    }
  }

  public async createPayout({ request, response, auth }: HttpContext) {
    this.assertAdmin(this.getUser(request, auth))
    
    const { wallet_id, amount, recipient_phone, recipient_name, external_reference, label } = request.only([
      'wallet_id',
      'amount',
      'recipient_phone',
      'recipient_name',
      'external_reference',
      'label',
    ])
    
    if (!wallet_id || !amount || !recipient_phone || !recipient_name) {
      return response.badRequest({ message: 'wallet_id, amount, recipient_phone, and recipient_name are required' })
    }

    try {
      const result = await adminService.createPayout({
        wallet_id,
        amount: Number(amount),
        recipient_phone,
        recipient_name,
        external_reference,
        label,
      })
      return response.created(result)
    } catch (error: any) {
      if (error.message.includes('not found') || error.message.includes('insuffisant') || error.message.includes('format')) {
        return response.badRequest({ message: error.message })
      }
      return response.internalServerError({ 
        message: 'Failed to create payout', 
        error: error.message 
      })
    }
  }

  public async release({ request, response, auth }: HttpContext) {
    this.assertAdmin(this.getUser(request, auth))

    const schema = vine.object({
      ledger_entry_id: vine.string().optional(),
      external_reference: vine.string().optional(),
      wallet_id: vine.string().optional(),
    })
    const validator = vine.compile(schema)
    const payload = await validator.validate(request.body())

    try {
      // Note: Seuls les ON_HOLD peuvent être libérés. Les LOCKED sont gérés uniquement par le système.
      if (payload.ledger_entry_id) {
        const entry = await releaseService.releaseHoldById(payload.ledger_entry_id)
        return response.ok({
          message: 'Fonds libérés avec succès',
          data: {
            entry_id: entry.id,
            wallet_id: entry.walletId,
            amount: entry.amount,
            funds_status: entry.fundsStatus,
          },
        })
      }

      if (payload.external_reference) {
        if (payload.wallet_id) {
          const entry = await releaseService.releaseHoldByReferenceAndWallet(
            payload.external_reference,
            payload.wallet_id
          )
          return response.ok({
            message: 'Fonds libérés avec succès',
            data: {
              entry_id: entry.id,
              wallet_id: entry.walletId,
              amount: entry.amount,
              funds_status: entry.fundsStatus,
            },
          })
        } else {
          const entries = await releaseService.releaseHoldByReference(payload.external_reference)
          return response.ok({
            message: `${entries.length} entrée(s) libérée(s) avec succès`,
            data: entries.map((entry: any) => ({
              entry_id: entry.id,
              wallet_id: entry.walletId,
              amount: entry.amount,
              funds_status: entry.fundsStatus,
            })),
          })
        }
      }

      return response.badRequest({
        message: 'Vous devez fournir soit ledger_entry_id, soit external_reference',
      })
    } catch (error: any) {
      if (error.message.includes('not found') || error.message.includes('No ON_HOLD')) {
        return response.notFound({ message: error.message })
      }
      if (error.message.includes('LOCKED') && error.message.includes('cannot be released manually')) {
        return response.forbidden({
          message: error.message,
        })
      }
      return response.badRequest({ message: error.message || 'Erreur lors de la libération' })
    }
  }

  public async refund({ request, response, auth }: HttpContext) {
    this.assertAdmin(this.getUser(request, auth))

    const schema = vine.object({
      payment_intent_id: vine.string(),
      amount: vine.number().withoutDecimals().min(1),
      reason: vine.string(),
      splits: vine.array(
        vine.object({
          wallet_id: vine.string(),
          amount: vine.number().withoutDecimals().min(1),
        })
      ),
      force: vine.boolean().optional(),
    })
    const validator = vine.compile(schema)
    const payload = await validator.validate(request.body())

    try {
      const result = await adminService.processRefund({
        payment_intent_id: payload.payment_intent_id,
        amount: payload.amount,
        reason: payload.reason,
        splits: payload.splits,
        force: payload.force,
      })
      return response.created(result)
    } catch (error: any) {
      if (error.status === 404 || error.message?.includes('not found')) {
        return response.notFound({ message: error.message || 'PaymentIntent non trouvé' })
      }
      return response.badRequest({ message: error.message || 'Erreur lors du refund' })
    }
  }
}

