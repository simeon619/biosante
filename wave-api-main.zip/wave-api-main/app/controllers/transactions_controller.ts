import type { HttpContext } from '@adonisjs/core/http'
import vine from '@vinejs/vine'
import db from '@adonisjs/lucid/services/db'
import Wallet from '#models/wallet'
import refundService from '#services/refund_service'
import ledgerService from '#services/ledger_service'
import releaseService from '#services/release_service'
import { generateId } from '#utils/id_generator'

export default class TransactionsController {
  private getManagerId(request: HttpContext['request']) {
    const managerId = request.header('x-manager-id')
    if (!managerId) {
      throw new Error('X-Manager-Id header is required')
    }
    return managerId
  }

  /**
   * Transfert interne (Wallet-to-Wallet)
   * Mouvement d'argent 100% virtuel entre deux wallets du même manager
   * Wave n'est pas impliqué
   */
  public async transfer({ request, response }: HttpContext) {
    const schema = vine.object({
      from_wallet_id: vine.string(),
      to_wallet_id: vine.string(),
      amount: vine.number().withoutDecimals().min(1),
      label: vine.string(),
      category: vine.enum(['ORDER_PAYMENT', 'SERVICE_PAYMENT', 'COMMISSION', 'ADJUSTMENT', 'SUBSCRIPTION'] as const),
      external_reference: vine.string().optional(),
      source_system: vine.string().optional(),
    })

    const validator = vine.compile(schema)
    const payload = await validator.validate(request.body())
    // Valeur par défaut pour source_system
    if (!payload.source_system) {
      payload.source_system = 'INTERNAL'
    }
    const managerId = this.getManagerId(request)

    // Vérifier que les wallets ne sont pas les mêmes
    if (payload.from_wallet_id === payload.to_wallet_id) {
      return response.badRequest({ message: 'Les wallets source et destination doivent être différents' })
    }

    try {
      await db.transaction(async (trx) => {
        // Verrouiller le wallet source
        const fromWallet = await Wallet.query({ client: trx })
          .where('id', payload.from_wallet_id)
          .andWhere('manager_id', managerId)
          .forUpdate()
          .firstOrFail()

        // Vérifier le solde disponible (avec overdraft_limit)
        // Calculer le solde disponible depuis les ledger entries AVAILABLE
        const currentBalance = await fromWallet.calculateBalanceAvailable()
        const newBalance = currentBalance - payload.amount
        if (newBalance < -fromWallet.overdraftLimit) {
          throw new Error(`Solde insuffisant. Solde disponible: ${currentBalance} XOF, Découvert autorisé: ${fromWallet.overdraftLimit} XOF`)
        }

        // Vérifier que le wallet n'est pas verrouillé
        if (fromWallet.isLocked) {
          throw new Error('Le wallet source est verrouillé')
        }

        // Verrouiller le wallet destination
        const toWallet = await Wallet.query({ client: trx })
          .where('id', payload.to_wallet_id)
          .andWhere('manager_id', managerId)
          .forUpdate()
          .firstOrFail()

        // Vérifier que le wallet destination n'est pas verrouillé
        if (toWallet.isLocked) {
          throw new Error('Le wallet destination est verrouillé')
        }

        // Vérifier que les wallets ont la même devise
        if (fromWallet.currency !== toWallet.currency) {
          throw new Error(`Les wallets doivent avoir la même devise. Source: ${fromWallet.currency}, Destination: ${toWallet.currency}`)
        }

        const txGroup = generateId('tx')
        const externalRef = payload.external_reference || `transfer_${txGroup}`

        // Créer le DEBIT sur le wallet source
        await ledgerService.recordEntry(
          {
            walletId: fromWallet.id,
            transactionGroupId: txGroup,
            amount: payload.amount,
            direction: 'DEBIT',
            category: payload.category,
            label: payload.label,
            sourceSystem: payload.source_system || 'INTERNAL',
            externalReference: externalRef,
            metadata: { 
              transfer_type: 'OUT',
              to_wallet_id: toWallet.id,
              to_wallet_owner: toWallet.ownerName || toWallet.ownerId,
            },
            fundsStatus: 'AVAILABLE',
          },
          trx
        )

        // Créer le CREDIT sur le wallet destination
        await ledgerService.recordEntry(
          {
            walletId: toWallet.id,
            transactionGroupId: txGroup,
            amount: payload.amount,
            direction: 'CREDIT',
            category: payload.category,
            label: payload.label,
            sourceSystem: payload.source_system || 'INTERNAL',
            externalReference: externalRef,
            metadata: { 
              transfer_type: 'IN',
              from_wallet_id: fromWallet.id,
              from_wallet_owner: fromWallet.ownerName || fromWallet.ownerId,
            },
            fundsStatus: 'AVAILABLE',
          },
          trx
        )
      })

      return response.created({ 
        message: 'Transfert effectué avec succès',
        data: {
          from_wallet_id: payload.from_wallet_id,
          to_wallet_id: payload.to_wallet_id,
          amount: payload.amount,
          currency: 'XOF',
        },
      })
    } catch (error: any) {
      if (error.message.includes('not found')) {
        return response.notFound({ message: 'Wallet non trouvé ou n\'appartient pas à votre manager' })
      }
      return response.badRequest({ message: error.message || 'Erreur lors du transfert' })
    }
  }

  public async release({ request, response }: HttpContext) {
    const schema = vine.object({
      ledger_entry_id: vine.string().optional(),
      external_reference: vine.string().optional(),
      wallet_id: vine.string().optional(),
    })
    const validator = vine.compile(schema)
    const payload = await validator.validate(request.body())

    try {
      // Option 1: Release par ledger_entry_id (ancienne méthode, rétrocompatible)
      if (payload.ledger_entry_id) {
        const entry = await releaseService.releaseHoldById(payload.ledger_entry_id)
        return response.ok({
          message: 'Fonds libérés avec succès',
          data: {
            entry_id: entry.id,
            wallet_id: entry.walletId,
            amount: entry.amount,
            funds_status: entry.fundsStatus,
          },
        })
      }

      // Option 2: Release par external_reference (nouvelle méthode)
      if (payload.external_reference) {
        if (payload.wallet_id) {
          // Release précis : external_reference + wallet_id
          const entry = await releaseService.releaseHoldByReferenceAndWallet(
            payload.external_reference,
            payload.wallet_id
          )
          return response.ok({
            message: 'Fonds libérés avec succès',
            data: {
              entry_id: entry.id,
              wallet_id: entry.walletId,
              amount: entry.amount,
              funds_status: entry.fundsStatus,
            },
          })
        } else {
          // Release par external_reference uniquement (peut libérer plusieurs entries)
          const entries = await releaseService.releaseHoldByReference(payload.external_reference)
          return response.ok({
            message: `${entries.length} entrée(s) libérée(s) avec succès`,
            data: entries.map((entry) => ({
              entry_id: entry.id,
              wallet_id: entry.walletId,
              amount: entry.amount,
              funds_status: entry.fundsStatus,
            })),
          })
        }
      }

      return response.badRequest({
        message: 'Vous devez fournir soit ledger_entry_id, soit external_reference',
      })
    } catch (error: any) {
      if (error.message.includes('not found') || error.message.includes('No ON_HOLD')) {
        return response.notFound({ message: error.message })
      }
      if (error.message.includes('LOCKED') && error.message.includes('cannot be released manually')) {
        return response.forbidden({
          message: error.message,
        })
      }
      return response.badRequest({ message: error.message || 'Erreur lors de la libération' })
    }
  }

  public async refund({ request, response }: HttpContext) {
    const schema = vine.object({
      payment_intent_id: vine.string(),
      amount: vine.number().withoutDecimals().min(1),
      reason: vine.string(),
      splits: vine.array(
        vine.object({
          wallet_id: vine.string(),
          amount: vine.number().withoutDecimals().min(1),
        })
      ),
      force: vine.boolean().optional(),
    })
    const validator = vine.compile(schema)
    const payload = await validator.validate(request.body())
    const managerId = this.getManagerId(request)

    try {
      const result = await refundService.processRefund({
        paymentIntentId: payload.payment_intent_id,
        amount: payload.amount,
        reason: payload.reason,
        splits: payload.splits,
        force: payload.force ?? false,
        sourceSystem: 'INTERNAL',
        managerId,
      })

      return response.created({
        message: 'Refund effectué avec succès',
        data: result,
      })
    } catch (error: any) {
      if (error.status === 403) {
        return response.forbidden({ message: error.message })
      }
      if (error.status === 404 || error.message?.includes('not found')) {
        return response.notFound({ message: error.message || 'PaymentIntent non trouvé' })
      }
      return response.badRequest({ message: error.message || 'Erreur lors du refund' })
    }
  }
}

