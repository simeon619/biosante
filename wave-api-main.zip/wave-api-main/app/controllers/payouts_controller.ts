import type { HttpContext } from '@adonisjs/core/http'
import vine from '@vinejs/vine'
import db from '@adonisjs/lucid/services/db'
import Wallet from '#models/wallet'
import ledgerService from '#services/ledger_service'
import waveGateway from '#services/wave_gateway_service'
import { generateId } from '#utils/id_generator'

export default class PayoutsController {
  private getManagerId(request: HttpContext['request']) {
    const managerId = request.header('x-manager-id')
    if (!managerId) {
      throw new Error('X-Manager-Id header is required')
    }
    return managerId
  }

  public async create({ request, response }: HttpContext) {
    const schema = vine.object({
      wallet_id: vine.string(),
      amount: vine.number().withoutDecimals().min(1),
      recipient_phone: vine.string(),
      recipient_name: vine.string().optional(),
      external_reference: vine.string(),
      label: vine.string(),
      source_system: vine.string(),
    })

    const payload = await request.validateUsing(vine.compile(schema))
    const managerId = this.getManagerId(request)

    const result = await db.transaction(async (trx) => {
      const wallet = await Wallet.query({ client: trx })
        .where('id', payload.wallet_id)
        .andWhere('manager_id', managerId)
        .forUpdate()
        .firstOrFail()

      // Calculer le solde disponible depuis les ledger entries AVAILABLE
      const currentBalance = await wallet.calculateBalanceAvailable()
      if (currentBalance < payload.amount) {
        throw new Error('Solde insuffisant')
      }

      const txGroup = generateId('po')
      const ledgerEntry = await ledgerService.recordEntry(
        {
          walletId: wallet.id,
          transactionGroupId: txGroup,
          amount: payload.amount,
          direction: 'DEBIT',
          category: 'PAYOUT',
          label: payload.label,
          sourceSystem: payload.source_system,
          externalReference: payload.external_reference,
          metadata: { beneficiary: payload.recipient_phone },
          fundsStatus: 'LOCKED',
        },
        trx
      )

      const payout = await waveGateway.sendPayout({
        amount: payload.amount,
        recipientPhone: payload.recipient_phone,
        recipientName: payload.recipient_name || 'Client',
        reference: payload.external_reference,
      })

      // Mettre à jour le statut du ledger selon la réponse immédiate de Wave
      // Les soldes sont maintenant calculés dynamiquement, donc pas besoin de modifier le wallet
      if (payout.status === 'succeeded') {
        ledgerEntry.fundsStatus = 'AVAILABLE'
      } else if (payout.status === 'failed') {
        // Si le payout échoue, changer le statut à FAILED
        // FAILED n'est pas comptabilisé dans les soldes (calculés dynamiquement)
        ledgerEntry.fundsStatus = 'FAILED'
      }
      // Si le statut est autre chose (pending, etc.), on garde LOCKED

      ledgerEntry.metadata = {
        ...(ledgerEntry.metadata || {}),
        wave_payout_id: payout.id,
        wave_payout_fee: payout.fee,
        wave_payout_status: payout.status,
        wave_payout_timestamp: payout.timestamp,
      }
      await ledgerEntry.save()

      return { ledgerEntry, payout }
    })

    return response.created({
      message: 'Payout initié',
      data: {
        ledger_entry_id: result.ledgerEntry.id,
        wave_payout_id: result.payout.id,
        status: result.payout.status,
      },
    })
  }
}

