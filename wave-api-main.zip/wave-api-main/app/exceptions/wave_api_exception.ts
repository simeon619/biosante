import { Exception } from '@adonisjs/core/exceptions'

export default class WaveApiException extends Exception {
  constructor(
    message: string,
    status: number = 500,
    code: string = 'WAVE_API_ERROR',
    data?: any
  ) {
    super(message, { status, code, ...data })
  }
}

