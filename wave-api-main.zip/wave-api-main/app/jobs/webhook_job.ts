import type { Job } from 'bullmq'
import webhookProcessor from '#services/webhook_processor_service'
import logger from '@adonisjs/core/services/logger'

export default async function webhookJob(job: Job) {
  const { waveEventId, type, payload } = job.data

  try {
    await webhookProcessor.processEvent(waveEventId, type, payload)
    return { status: 'processed' }
  } catch (error) {
    logger.error({ jobId: job.id, err: error }, '[WebhookJob] Processing failed')
    throw error
  }
}

