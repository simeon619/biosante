import type { Job } from 'bullmq'
import releaseService from '#services/release_service'
import logger from '@adonisjs/core/services/logger'

export default async function releaseHoldJob(job: Job) {
  try {
    const releasedCount = await releaseService.releaseExpiredHolds()
    logger.info({ jobId: job.id, releasedCount }, '[ReleaseHoldJob] Processed expired holds')
    return { status: 'processed', releasedCount }
  } catch (error) {
    logger.error({ jobId: job.id, err: error }, '[ReleaseHoldJob] Processing failed')
    throw error
  }
}

