import type { HttpContext } from '@adonisjs/core/http'
import type { NextFn } from '@adonisjs/core/types/http'

/**
 * Middleware pour capturer le raw body avant que le body parser ne le consomme
 * Nécessaire pour la vérification de signature des webhooks
 */
export default class CaptureRawBodyMiddleware {
  async handle(ctx: HttpContext, next: NextFn) {
    const { request } = ctx

    // Seulement pour la route webhook
    if (request.url().includes('/webhook/wave')) {
      try {
        // Accéder à l'objet request Node.js natif (IncomingMessage)
        const nodeRequest = (request as any).request || (request as any).req
        
        if (nodeRequest && nodeRequest.readable && !nodeRequest._read) {
          // Le stream n'a pas encore été lu
          const chunks: Buffer[] = []
          
          // Lire tout le stream
          for await (const chunk of nodeRequest as any) {
            chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk))
          }
          
          const rawBody = Buffer.concat(chunks).toString('utf-8')
          ;(request as any)._rawBody = rawBody
          
          // Restaurer le stream pour que le body parser puisse le lire
          ;(nodeRequest as any).body = rawBody
        } else if (nodeRequest && nodeRequest.body) {
          // Le body a déjà été lu par le body parser
          // Essayer de le récupérer depuis request.raw() ou le reconstruire
          const raw = request.raw()
          if (raw) {
            ;(request as any)._rawBody = typeof raw === 'string' ? raw : String(raw)
          }
        }
      } catch (error) {
        // En cas d'erreur, on continue sans raw body
        // Le contrôleur utilisera JSON.stringify en fallback
      }
    }

    await next()
  }
}

