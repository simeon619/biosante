import type { HttpContext } from '@adonisjs/core/http'
import type { NextFn } from '@adonisjs/core/types/http'
import User from '#models/user'
import hash from '@adonisjs/core/services/hash'

export default class ServerAuthMiddleware {
  public async handle({ request, response }: HttpContext, next: NextFn) {
    // Skip authentication for OPTIONS requests (CORS preflight)
    if (request.method() === 'OPTIONS') {
      return next()
    }
    
    const authorization = request.header('authorization')
    const managerId = request.header('x-manager-id')

    if (!authorization || !managerId) {
      return response.unauthorized({ message: 'Authorization and X-Manager-Id headers are required' })
    }

    const [type, token] = authorization.split(' ')
    if (!token || type?.toLowerCase() !== 'bearer') {
      return response.unauthorized({ message: 'Bearer token invalid' })
    }

    const user = await User.find(managerId)
    if (!user || !user.isActive || !user.apiKeyHash) {
      return response.unauthorized({ message: 'Manager not authorized' })
    }

    const isValid = await hash.verify(user.apiKeyHash, token)
    if (!isValid) {
      return response.unauthorized({ message: 'Invalid API key' })
    }

    ;(request as any).manager = user
    ;(request as any).user = user

    return next()
  }
}

