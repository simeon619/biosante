import { DateTime } from 'luxon'
import { BaseModel, beforeCreate, column, afterCreate } from '@adonisjs/lucid/orm'
import { generateId } from '../utils/id_generator.js'
import eventBus from '#services/event_bus'

export default class WebhookEvent extends BaseModel {
  @column({ isPrimary: true })
  declare id: string

  @beforeCreate()
  static assignId(event: WebhookEvent) {
    event.id = generateId('evt')
  }

  @column()
  declare waveEventId: string

  @column()
  declare type: string

  @column()
  declare payload: Record<string, any>

  @column()
  declare status: 'PENDING' | 'PROCESSED' | 'FAILED' | 'IGNORED'

  @column()
  declare processingError: string | null

  @column.dateTime({ autoCreate: true })
  declare createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true })
  declare updatedAt: DateTime

  @afterCreate()
  static emitSseEvent(event: WebhookEvent) {
    eventBus.emitEvent({
      type: 'webhook.new',
      referenceId: event.id,
      scopes: ['admin', 'webhook'],
      payload: {
        id: event.id,
        waveEventId: event.waveEventId,
        type: event.type,
        status: event.status,
        createdAt: event.createdAt,
      },
    })
  }
}