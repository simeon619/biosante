import { DateTime } from 'luxon'
import { BaseModel, beforeCreate, belongsTo, column, afterCreate } from '@adonisjs/lucid/orm'
import { generateId } from '../utils/id_generator.js'
import Wallet from './wallet.js'
import type { BelongsTo } from '@adonisjs/lucid/types/relations'
import eventBus from '#services/event_bus'

export default class LedgerEntry extends BaseModel {
  @column({ isPrimary: true })
  declare id: string

  @beforeCreate()
  static assignId(entry: LedgerEntry) {
    entry.id = generateId('ldg')
  }

  @column()
  declare walletId: string

  @belongsTo(() => Wallet)
  declare wallet: BelongsTo<typeof Wallet>

  @column()
  declare transactionGroupId: string

  @column()
  declare amount: number

  @column()
  declare direction: 'CREDIT' | 'DEBIT'

  @column()
  declare category:
    | 'ORDER_PAYMENT'
    | 'SERVICE_PAYMENT'
    | 'COMMISSION'
    | 'DEPOSIT'
    | 'PAYOUT'
    | 'REFUND'
    | 'ADJUSTMENT'
    | 'SUBSCRIPTION'

  @column()
  declare label: string

  @column()
  declare sourceSystem: string

  @column()
  declare externalReference: string

  @column({
    prepare: (value: Record<string, any> | undefined) => JSON.stringify(value ?? {}),
  })
  declare metadata: Record<string, any>

  @column()
  declare fundsStatus: 'ON_HOLD' | 'AVAILABLE' | 'LOCKED' | 'FAILED' | 'CANCELED' | 'REFUNDED'

  @column.dateTime()
  declare releaseScheduledAt: DateTime | null

  @column.dateTime()
  declare releasedAt: DateTime | null

  @column.dateTime({ autoCreate: true })
  declare createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true })
  declare updatedAt: DateTime

  @afterCreate()
  static async emitSseEvent(entry: LedgerEntry) {
    const logger = (await import('@adonisjs/core/services/logger')).default
    logger.info({ ledgerEntryId: entry.id, walletId: entry.walletId }, '[LedgerEntry] @afterCreate hook déclenché - émission SSE')
    
    const wallet = await Wallet.find(entry.walletId)

    const scopes = new Set<string>(['admin', `wallet:${entry.walletId}`])
    if (wallet?.managerId) {
      scopes.add(`manager:${wallet.managerId}`)
    }
    // Note: ownerId n'est pas un User, donc pas de scope user:${ownerId}
    // Le wallet représente déjà le owner via wallet:${walletId}

    logger.info({ ledgerEntryId: entry.id, scopes: Array.from(scopes) }, '[LedgerEntry] Émission événement SSE ledger.new')
    
    eventBus.emitEvent({
      type: 'ledger.new',
      referenceId: entry.id,
      scopes: Array.from(scopes),
      payload: {
        id: entry.id,
        walletId: entry.walletId,
        amount: entry.amount,
        direction: entry.direction,
        category: entry.category,
        label: entry.label,
        fundsStatus: entry.fundsStatus,
        createdAt: entry.createdAt,
      },
    })
    
    logger.info({ ledgerEntryId: entry.id }, '[LedgerEntry] Événement SSE ledger.new émis')
  }
}