import { DateTime } from 'luxon'
import { BaseModel, beforeCreate, beforeDelete, belongsTo, column, hasMany, afterCreate, afterUpdate, afterDelete, afterFind, afterFetch } from '@adonisjs/lucid/orm'
import { generateId } from '../utils/id_generator.js'
import User from './user.js'
import type { BelongsTo, HasMany } from '@adonisjs/lucid/types/relations'
import LedgerEntry from './ledger_entry.js'
import eventBus from '#services/event_bus'
import db from '@adonisjs/lucid/services/db'

export default class Wallet extends BaseModel {
  @column({ isPrimary: true })
  declare id: string

  @beforeCreate()
  static assignId(wallet: Wallet) {
    wallet.id = generateId('wlt')
  }

  @beforeDelete()
  static async preventMainWalletDeletion(wallet: Wallet) {
    // Vérifier si ce wallet est le wallet principal d'un user
    const user = await User.findBy('mainWalletId', wallet.id)
    if (user) {
      throw new Error('Cannot delete main wallet. It is linked to a user as their primary wallet.')
    }
  }

  @column()
  declare managerId: string

  @belongsTo(() => User, { foreignKey: 'managerId' })
  declare manager: BelongsTo<typeof User>

  @column()
  declare ownerId: string

  @column()
  declare ownerName: string | null

  @column()
  declare ownerWavePhone: string | null

  @column()
  declare entityType: 'DRIVER' | 'VENDOR' | 'CLIENT' | 'PLATFORM'

  // Note: balanceAccounting et balanceAvailable sont maintenant des propriétés calculées
  // Les colonnes existent toujours en base pour compatibilité mais ne sont plus utilisées
  @column({ serializeAs: null })
  declare _balanceAccounting: number | null

  @column({ serializeAs: null })
  declare _balanceAvailable: number | null

  /**
   * Solde comptable : somme des (CREDIT - DEBIT) où fundsStatus IN ('AVAILABLE', 'ON_HOLD', 'LOCKED')
   * Calculé dynamiquement depuis les ledger entries
   * Utilise un cache pour éviter les requêtes répétées
   */
  get balanceAccounting(): number {
    // Si la valeur est déjà calculée et mise en cache, la retourner
    if (this._balanceAccounting !== null && this._balanceAccounting !== undefined) {
      return this._balanceAccounting
    }
    // Sinon, retourner 0 (sera calculé par afterFind/afterFetch)
    return 0
  }

  /**
   * Solde disponible : somme des (CREDIT - DEBIT) où fundsStatus = 'AVAILABLE'
   * Calculé dynamiquement depuis les ledger entries
   * Utilise un cache pour éviter les requêtes répétées
   */
  get balanceAvailable(): number {
    // Si la valeur est déjà calculée et mise en cache, la retourner
    if (this._balanceAvailable !== null && this._balanceAvailable !== undefined) {
      return this._balanceAvailable
    }
    // Sinon, retourner 0 (sera calculé par afterFind/afterFetch)
    return 0
  }

  /**
   * Calcule le balanceAccounting depuis les ledger entries
   * fundsStatus IN ('AVAILABLE', 'ON_HOLD', 'LOCKED')
   */
  async calculateBalanceAccounting(): Promise<number> {
    const result = await db
      .from('ledger_entries')
      .where('wallet_id', this.id)
      .whereIn('funds_status', ['AVAILABLE', 'ON_HOLD', 'LOCKED'])
      .select(db.raw(`
        COALESCE(
          SUM(CASE WHEN direction = 'CREDIT' THEN amount::numeric ELSE -amount::numeric END),
          0
        ) as balance
      `))
      .first()

    const balance = Number(result?.balance || 0)
    // Mettre en cache
    ;(this as any)._balanceAccounting = balance
    return balance
  }

  /**
   * Calcule le balanceAvailable depuis les ledger entries
   * fundsStatus = 'AVAILABLE'
   */
  async calculateBalanceAvailable(): Promise<number> {
    const result = await db
      .from('ledger_entries')
      .where('wallet_id', this.id)
      .where('funds_status', 'AVAILABLE')
      .select(db.raw(`
        COALESCE(
          SUM(CASE WHEN direction = 'CREDIT' THEN amount::numeric ELSE -amount::numeric END),
          0
        ) as balance
      `))
      .first()

    const balance = Number(result?.balance || 0)
    // Mettre en cache
    ;(this as any)._balanceAvailable = balance
    return balance
  }

  @column()
  declare overdraftLimit: number

  @column()
  declare currency: string

  @column()
  declare isLocked: boolean

  @hasMany(() => LedgerEntry)
  declare entries: HasMany<typeof LedgerEntry>

  @column.dateTime({ autoCreate: true })
  declare createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true })
  declare updatedAt: DateTime

  @afterCreate()
  static async emitCreateEvent(wallet: Wallet) {
    await Wallet.emitSse(wallet, 'wallet.created')
  }

  @afterUpdate()
  static async emitUpdateEvent(wallet: Wallet) {
    await Wallet.emitSse(wallet, 'wallet.updated')
  }

  @afterDelete()
  static async emitDeleteEvent(wallet: Wallet) {
    await Wallet.emitSse(wallet, 'wallet.deleted')
  }

  /**
   * Après la récupération d'un wallet, calculer les soldes depuis les ledger entries
   */
  @afterFind()
  static async calculateBalances(wallet: Wallet) {
    await wallet.calculateBalanceAccounting()
    await wallet.calculateBalanceAvailable()
  }

  /**
   * Après la récupération de plusieurs wallets, calculer les soldes pour chacun
   */
  @afterFetch()
  static async calculateBalancesForAll(wallets: Wallet[]) {
    // Calculer les soldes pour tous les wallets en parallèle
    await Promise.all(wallets.map((wallet) => wallet.calculateBalanceAccounting()))
    await Promise.all(wallets.map((wallet) => wallet.calculateBalanceAvailable()))
  }

  private static async emitSse(wallet: Wallet, type: string) {
    const scopes = new Set<string>(['admin', `wallet:${wallet.id}`])
    if (wallet.managerId) scopes.add(`manager:${wallet.managerId}`)
    // Note: ownerId n'est pas un User, donc pas de scope user:${ownerId}
    // Le wallet représente déjà le owner via wallet:${wallet.id}

    // Calculer les soldes avant d'émettre l'événement
    const balanceAccounting = await wallet.calculateBalanceAccounting()
    const balanceAvailable = await wallet.calculateBalanceAvailable()

    eventBus.emitEvent({
      type,
      referenceId: wallet.id,
      scopes: Array.from(scopes),
      payload: {
        id: wallet.id,
        managerId: wallet.managerId,
        ownerId: wallet.ownerId,
        entityType: wallet.entityType,
        balanceAvailable,
        balanceAccounting,
        currency: wallet.currency,
        isLocked: wallet.isLocked,
        updatedAt: wallet.updatedAt,
      },
    })
  }
}