import { DateTime } from 'luxon'
import { BaseModel, beforeCreate, column, afterCreate, afterUpdate, afterDelete } from '@adonisjs/lucid/orm'
import { generateId } from '../utils/id_generator.js'
import eventBus from '#services/event_bus'
import Wallet from './wallet.js'

export interface SplitConfigItem {
  wallet_id: string
  amount: number
  category: string
  label: string
  external_reference?: string
  release_delay_hours?: number
  allow_early_release?: boolean
}

export default class PaymentIntent extends BaseModel {
  @column({ isPrimary: true })
  declare id: string

  @beforeCreate()
  static assignId(intent: PaymentIntent) {
    intent.id = generateId('pi')
  }

  @column()
  declare externalReference: string

  @column()
  declare sourceSystem: string

  @column()
  declare amount: number

  @column()
  declare currency: string

  @column()
  declare payerId: string | null

  @column()
  declare description: string | null

  @column()
  declare aggregatedMerchantId: string | null

  @column()
  declare waveSessionId: string | null

  @column()
  declare waveCheckoutUrl: string | null

  @column()
  declare status: 'PENDING' | 'WAVE_CREATED' | 'COMPLETED' | 'FAILED'

  @column({
    prepare: (value: unknown) => JSON.stringify(value ?? []),
   })
  declare splitsConfig: SplitConfigItem[]

  @column.dateTime({ autoCreate: true })
  declare createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true })
  declare updatedAt: DateTime

  @afterCreate()
  static async emitCreateEvent(intent: PaymentIntent) {
    await PaymentIntent.emitSse(intent, 'intent.created')
  }

  @afterUpdate()
  static async emitUpdateEvent(intent: PaymentIntent) {
    await PaymentIntent.emitSse(intent, 'intent.updated')
  }

  @afterDelete()
  static async emitDeleteEvent(intent: PaymentIntent) {
    await PaymentIntent.emitSse(intent, 'intent.deleted')
  }

  private static async emitSse(intent: PaymentIntent, type: string) {
    const logger = (await import('@adonisjs/core/services/logger')).default
    logger.info({ intentId: intent.id, type }, '[PaymentIntent] Émission événement SSE')
    
    const scopes = new Set<string>(['admin', `intent:${intent.id}`])
    if (intent.payerId) {
      scopes.add(`wallet:${intent.payerId}`)
    }

    const walletIds = Array.from(
      new Set((intent.splitsConfig || []).map((split) => split.wallet_id).filter(Boolean))
    )

    if (walletIds.length > 0) {
      const wallets = await Wallet.query().whereIn('id', walletIds)
      for (const wallet of wallets) {
        scopes.add(`wallet:${wallet.id}`)
        if (wallet.managerId) scopes.add(`manager:${wallet.managerId}`)
        // Note: ownerId n'est pas un User, donc pas de scope user:${ownerId}
        // Le wallet représente déjà le owner via wallet:${wallet.id}
      }
    }

    logger.info({ intentId: intent.id, type, scopes: Array.from(scopes) }, '[PaymentIntent] Scopes calculés pour SSE')

    eventBus.emitEvent({
      type,
      referenceId: intent.id,
      scopes: Array.from(scopes),
      payload: {
        id: intent.id,
        status: intent.status,
        amount: intent.amount,
        currency: intent.currency,
        payerId: intent.payerId,
        splits: intent.splitsConfig,
        updatedAt: intent.updatedAt,
      },
    })
    
    logger.info({ intentId: intent.id, type }, '[PaymentIntent] Événement SSE émis')
  }
}