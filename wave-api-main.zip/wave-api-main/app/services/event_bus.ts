import { EventEmitter } from 'node:events'
import logger from '@adonisjs/core/services/logger'
import transmit from '@adonisjs/transmit/services/main'

export type SseEvent = {
  type: string
  referenceId?: string
  scopes: string[]
  payload?: Record<string, any>
  timestamp?: string
}

class EventBus extends EventEmitter {
  emitEvent(event: SseEvent) {
    const payload: SseEvent = {
      ...event,
      timestamp: event.timestamp || new Date().toISOString(),
    }

    logger.info({ type: payload.type, referenceId: payload.referenceId, scopes: payload.scopes }, '[EventBus] Émission événement SSE')

    this.emit('event', payload)

    const channels = this.normalizeScopes(payload.scopes)
    logger.info({ type: payload.type, channels }, '[EventBus] Canaux Transmit normalisés')
    
    for (const channel of channels) {
      try {
        transmit.broadcast(channel, payload)
        logger.info({ type: payload.type, channel }, '[EventBus] Événement diffusé sur canal Transmit')
      } catch (error) {
        logger.warn({ channel, error }, '[EventBus] Échec diffusion Transmit')
      }
    }
    
    logger.info({ type: payload.type, channelsCount: channels.length }, '[EventBus] Émission SSE terminée')
  }

  private normalizeScopes(scopes?: string[]) {
    const values = scopes && scopes.length > 0 ? scopes : ['admin']
    const normalized = values
      .filter((scope): scope is string => typeof scope === 'string' && scope.trim().length > 0)
      .map((scope) => scope.replace(/:/g, '/'))
    return Array.from(new Set(normalized))
  }
}

export default new EventBus()


