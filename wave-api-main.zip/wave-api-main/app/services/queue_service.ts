import { Queue } from 'bullmq'
import { Redis as IORedis } from 'ioredis'
import env from '#start/env'

class QueueService {
  private connection = new IORedis({
    host: env.get('REDIS_HOST'),
    port: env.get('REDIS_PORT'),
    password: env.get('REDIS_PASSWORD'),
    maxRetriesPerRequest: null,
  })

  private queues = new Map<string, Queue>()

  public getConnection() {
    return this.connection
  }

  public getQueue(name: string) {
    if (!this.queues.has(name)) {
      this.queues.set(
        name,
        new Queue(name, {
          connection: this.connection,
        })
      )
    }
    return this.queues.get(name)!
  }

  public async addJob(queueName: string, jobName: string, data: any, options = {}) {
    const queue = this.getQueue(queueName)
    return queue.add(jobName, data, options)
  }
}

export default new QueueService()

