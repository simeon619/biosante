import env from '#start/env'
import logger from '@adonisjs/core/services/logger'
import WaveApiException from '#exceptions/wave_api_exception'

interface WaveCheckoutSession {
  id: string
  checkout_url?: string
  wave_launch_url?: string
  amount: string
  currency: string
  payment_status?: string
}

interface WavePayout {
  id: string
  currency: string
  receive_amount: string
  fee?: string
  mobile: string
  name: string
  status: string
  timestamp: string
}

class WaveGatewayService {
  private baseUrl = 'https://api.wave.com'
  private apiKey = env.get('WAVE_API_KEY')

  private async request<T>(method: 'GET' | 'POST', endpoint: string, body?: any, customHeaders?: Record<string, string>): Promise<T> {
    const url = `${this.baseUrl}${endpoint}`
    const headers: Record<string, string> = {
      Authorization: `Bearer ${this.apiKey}`,
      'Content-Type': 'application/json',
      ...customHeaders,
    }

    try {
      const response = await fetch(url, {
        method,
        headers,
        body: body ? JSON.stringify(body) : undefined,
      })

      const data = (await response.json()) as any

      if (!response.ok) {
        logger.error({ status: response.status, data, endpoint }, '[WaveGateway] API error')
        throw new WaveApiException(
          data.message || data.error || 'Wave error',
          response.status,
          data.code || 'wave_error',
          data
        )
      }

      return data as T
    } catch (error) {
      if (error instanceof WaveApiException) {
        throw error
      }
      logger.error({ err: error, endpoint }, '[WaveGateway] Network error')
      throw new WaveApiException('Network error connecting to Wave', 500, 'network_error', error)
    }
  }

  public async createCheckoutSession(params: {
    amount: number
    currency: string
    successUrl: string
    errorUrl: string
    clientReference?: string
    aggregatedMerchantId?: string
  }): Promise<WaveCheckoutSession> {
    const amountString = Math.floor(params.amount).toString()

    const payload: Record<string, any> = {
      amount: amountString,
      currency: params.currency,
      success_url: params.successUrl,
      error_url: params.errorUrl,
      client_reference: params.clientReference,
    }

    if (params.aggregatedMerchantId) {
      payload.aggregated_merchant_id = params.aggregatedMerchantId
    }

    logger.info({ ref: params.clientReference }, '[WaveGateway] Creating checkout session')
    return this.request<WaveCheckoutSession>('POST', '/v1/checkout/sessions', payload)
  }

  public async sendPayout(params: { amount: number; recipientPhone: string; recipientName: string; reference?: string }): Promise<WavePayout> {
    // Retirer les espaces du numéro de téléphone pour Wave
    const mobile = params.recipientPhone.replace(/\s+/g, '')
    
    const payload = {
      currency: 'XOF',
      receive_amount: Math.floor(params.amount).toString(),
      mobile: mobile,
      name: params.recipientName,
    }

    // Générer un Idempotency-Key basé sur les paramètres pour garantir l'idempotence
    const idempotencyKey = params.reference 
      ? `payout-${params.reference}-${mobile}-${params.amount}`
      : `payout-${mobile}-${params.amount}-${Date.now()}`

    logger.info({ mobile, name: params.recipientName, amount: params.amount, originalPhone: params.recipientPhone }, '[WaveGateway] Sending payout')
    return this.request<WavePayout>('POST', '/v1/payout', payload, {
      'idempotency-key': idempotencyKey,
    })
  }

  public async refundSession(sessionId: string, params: { amount?: number; reason?: string }) {
    const payload: Record<string, any> = {
      reason: params.reason || 'Customer request',
    }
    if (params.amount) {
      payload.amount = Math.floor(params.amount).toString()
    }

    logger.info({ sessionId }, '[WaveGateway] Refunding session')
    return this.request('POST', `/v1/checkout/sessions/${sessionId}/refund`, payload)
  }

  public async getSessionStatus(sessionId: string) {
    return this.request<WaveCheckoutSession>('GET', `/v1/checkout/sessions/${sessionId}`)
  }

  public async getBalance(): Promise<{ amount: string; currency: string }> {
    logger.info('[WaveGateway] Fetching account balance')
    return this.request<{ amount: string; currency: string }>('GET', '/v1/balance')
  }
}

export default new WaveGatewayService()

