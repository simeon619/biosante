import db from '@adonisjs/lucid/services/db'
import { Exception } from '@adonisjs/core/exceptions'
import logger from '@adonisjs/core/services/logger'
import PaymentIntent from '#models/payment_intent'
import Wallet from '#models/wallet'
import LedgerEntry from '#models/ledger_entry'
import waveGateway from '#services/wave_gateway_service'
import ledgerService from '#services/ledger_service'
import { generateId } from '#utils/id_generator'
import type { TransactionClientContract } from '@adonisjs/lucid/types/database'

type RefundSplit = {
  wallet_id: string
  amount: number
}

type RefundParams = {
  paymentIntentId: string
  amount: number
  reason: string
  splits: RefundSplit[]
  force?: boolean
  sourceSystem: string
  managerId?: string // Optionnel, pour vérifier l'appartenance au manager
}

class RefundService {
  /**
   * Valide les paramètres de refund
   */
  private async validateRefund(params: RefundParams) {
    // Récupérer le PaymentIntent
    const intent = await PaymentIntent.query().where('id', params.paymentIntentId).firstOrFail()

    // Vérifier que le PaymentIntent appartient au manager (si managerId fourni)
    if (params.managerId) {
      const intentWallets = intent.splitsConfig.map((s) => s.wallet_id)
      const managerWallets = (
        await Wallet.query()
          .whereIn('id', intentWallets)
          .andWhere('manager_id', params.managerId)
          .select('id')
      ).map((w) => w.id)

      if (managerWallets.length === 0) {
        throw new Exception('PaymentIntent non trouvé ou n\'appartient pas à votre manager', { status: 403 })
      }
    }

    // Valider le montant refund
    if (params.amount > intent.amount) {
      throw new Exception(
        `Le montant refund (${params.amount}) ne peut pas dépasser le montant original (${intent.amount})`,
        { status: 400 }
      )
    }

    // Valider les splits
    const totalSplits = params.splits.reduce((sum, split) => sum + split.amount, 0)
    if (totalSplits !== params.amount) {
      throw new Exception(
        `La somme des splits (${totalSplits}) ne correspond pas au montant refund (${params.amount})`,
        { status: 400 }
      )
    }

    // Vérifier que chaque split correspond à un wallet du PaymentIntent original
    const originalWalletIds = new Set(intent.splitsConfig.map((s) => s.wallet_id))
    for (const split of params.splits) {
      if (!originalWalletIds.has(split.wallet_id)) {
        throw new Exception(`Le wallet ${split.wallet_id} n'a pas reçu de fonds dans ce PaymentIntent`, { status: 400 })
      }

      // Vérifier que le montant refund ne dépasse pas le montant reçu
      const originalSplit = intent.splitsConfig.find((s) => s.wallet_id === split.wallet_id)
      if (!originalSplit || split.amount > originalSplit.amount) {
        throw new Exception(
          `Le refund pour le wallet ${split.wallet_id} (${split.amount}) dépasse le montant reçu (${originalSplit?.amount || 0})`,
          { status: 400 }
        )
      }
    }

    // Vérifier les fonds disponibles (sauf si force)
    if (!params.force) {
      for (const split of params.splits) {
        const wallet = await Wallet.query().where('id', split.wallet_id).firstOrFail()
        // Calculer le solde disponible depuis les ledger entries AVAILABLE
        const currentBalance = await wallet.calculateBalanceAvailable()
        const newBalance = currentBalance - split.amount
        if (newBalance < -wallet.overdraftLimit) {
          throw new Exception(
            `Solde insuffisant pour le wallet ${split.wallet_id}. Utilisez force: true pour forcer le refund.`,
            { status: 400 }
          )
        }
      }
    }

    // Vérifier que le PaymentIntent a un waveSessionId
    if (!intent.waveSessionId) {
      throw new Exception('PaymentIntent sans waveSessionId', { status: 400 })
    }

    return intent
  }

  /**
   * Traite un refund pour un split donné
   */
  private async processRefundSplit(
    split: RefundSplit,
    intent: PaymentIntent,
    txGroup: string,
    waveRefund: any,
    reason: string,
    sourceSystem: string,
    force: boolean,
    trx: TransactionClientContract
  ) {
    const wallet = await Wallet.query({ client: trx }).where('id', split.wallet_id).forUpdate().firstOrFail()

    // Trouver l'entrée ledger originale (CREDIT) pour ce wallet
    const originalEntry = await LedgerEntry.query({ client: trx })
      .where('wallet_id', split.wallet_id)
      .where('transaction_group_id', intent.id)
      .where('direction', 'CREDIT')
      .where('funds_status', '!=', 'CANCELED')
      .where('funds_status', '!=', 'REFUNDED')
      .firstOrFail()

    const refundAmount = split.amount
    const remainingAmount = originalEntry.amount - refundAmount

    if (originalEntry.fundsStatus === 'AVAILABLE') {
      // Cas AVAILABLE : créer un DEBIT AVAILABLE avec category REFUND
      // On ne CANCEL pas l'entrée originale, on crée juste un DEBIT qui réduit le solde
      const debitRefundEntry = await ledgerService.recordEntry(
        {
          walletId: wallet.id,
          transactionGroupId: txGroup,
          amount: refundAmount,
          direction: 'DEBIT',
          category: 'REFUND',
          label: reason,
          sourceSystem: sourceSystem,
          externalReference: `refund_${intent.id}`,
          metadata: {
            payment_intent_id: intent.id,
            previous_entry_id: originalEntry.id, // Lien vers l'entrée originale
            wave_refund: waveRefund,
            force: force,
          },
          fundsStatus: 'AVAILABLE', // AVAILABLE car l'entrée originale était AVAILABLE
          allowOverdraft: force,
        },
        trx
      )

      // Mettre à jour les métadonnées de l'entrée originale avec l'ID du DEBIT REFUND (optionnel, pour traçabilité)
      originalEntry.metadata = {
        ...(originalEntry.metadata || {}),
        refund_entry_id: debitRefundEntry.id, // Lien vers le DEBIT REFUND
      }
      await originalEntry.save()
    } else {
      // Cas ON_HOLD ou LOCKED : créer nouvelle entrée et CANCEL l'ancienne
      let newEntryId: string | undefined = undefined

      if (remainingAmount > 0) {
        // Créer nouvelle entrée ON_HOLD/LOCKED avec le montant restant
        const newEntry = await ledgerService.recordEntry(
          {
            walletId: wallet.id,
            transactionGroupId: intent.id,
            amount: remainingAmount,
            direction: 'CREDIT',
            category: originalEntry.category as any,
            label: originalEntry.label,
            sourceSystem: originalEntry.sourceSystem,
            externalReference: originalEntry.externalReference,
            metadata: {
              ...originalEntry.metadata,
              previous_entry_id: originalEntry.id, // Lien vers l'entrée originale
              refund_amount: refundAmount,
            },
            fundsStatus: originalEntry.fundsStatus,
            releaseDelayHours: originalEntry.releaseScheduledAt
              ? Math.max(0, Math.ceil(originalEntry.releaseScheduledAt.diffNow('hours').hours))
              : undefined,
          },
          trx
        )
        newEntryId = newEntry.id
      }

      // CANCEL l'ancienne entrée
      await ledgerService.cancelEntry(originalEntry.id, reason, newEntryId, trx)

      // Créer l'entrée DEBIT REFUNDED (n'impacte pas balanceAvailable)
      const debitRefundEntry = await ledgerService.recordEntry(
        {
          walletId: wallet.id,
          transactionGroupId: txGroup,
          amount: refundAmount,
          direction: 'DEBIT',
          category: 'REFUND',
          label: reason,
          sourceSystem: sourceSystem,
          externalReference: `refund_${intent.id}`,
          metadata: {
            payment_intent_id: intent.id,
            previous_entry_id: originalEntry.id, // Lien vers l'entrée originale
            wave_refund: waveRefund,
            force: force,
          },
          fundsStatus: 'REFUNDED', // REFUNDED car l'entrée originale était ON_HOLD/LOCKED
          allowOverdraft: force,
        },
        trx
      )

      // Mettre à jour les métadonnées du CANCELED avec les IDs des nouveaux ledgers
      const canceledEntry = await LedgerEntry.query({ client: trx }).where('id', originalEntry.id).firstOrFail()
      canceledEntry.metadata = {
        ...canceledEntry.metadata,
        next_entry_id: newEntryId, // ID du nouveau ledger ON_HOLD/LOCKED (si partiel)
        refund_entry_id: debitRefundEntry.id, // ID du DEBIT REFUNDED
      }
      await canceledEntry.save()
    }
  }

  /**
   * Exécute un refund complet
   */
  public async processRefund(params: RefundParams) {
    // Valider les paramètres
    const intent = await this.validateRefund(params)

    // Appeler l'API Wave
    const waveRefund = await waveGateway.refundSession(intent.waveSessionId!, {
      amount: params.amount,
      reason: params.reason,
    })

    // Traiter le refund dans une transaction
    const txGroup = generateId('rf')
    await db.transaction(async (trx) => {
      for (const split of params.splits) {
        await this.processRefundSplit(
          split,
          intent,
          txGroup,
          waveRefund,
          params.reason,
          params.sourceSystem,
          params.force || false,
          trx
        )
      }
    })

    logger.info({ paymentIntentId: intent.id, refundAmount: params.amount }, '[RefundService] Refund processed')

    return {
      payment_intent_id: intent.id,
      refund_amount: params.amount,
      wave_refund: waveRefund,
    }
  }
}

export default new RefundService()

