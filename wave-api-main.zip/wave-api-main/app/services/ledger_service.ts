import db from '@adonisjs/lucid/services/db'
import LedgerEntry from '#models/ledger_entry'
import Wallet from '#models/wallet'
import { DateTime } from 'luxon'
import type { TransactionClientContract } from '@adonisjs/lucid/types/database'

type RecordEntryPayload = {
  walletId: string
  transactionGroupId: string
  amount: number
  direction: 'CREDIT' | 'DEBIT'
  category:
    | 'ORDER_PAYMENT'
    | 'SERVICE_PAYMENT'
    | 'COMMISSION'
    | 'DEPOSIT'
    | 'PAYOUT'
    | 'REFUND'
    | 'ADJUSTMENT'
    | 'SUBSCRIPTION'
  label: string
  sourceSystem: string
  externalReference: string
  metadata?: Record<string, any>
  fundsStatus: 'ON_HOLD' | 'AVAILABLE' | 'LOCKED' | 'FAILED' | 'CANCELED' | 'REFUNDED' 
  releaseDelayHours?: number
  allowOverdraft?: boolean
}

class LedgerService {
  private async persistEntry(payload: RecordEntryPayload, trx: TransactionClientContract) {
    const wallet = await Wallet.query({ client: trx }).where('id', payload.walletId).forUpdate().firstOrFail()

    // Pour les DEBIT, vérifier le solde disponible avant de créer l'entrée
    if (payload.direction === 'DEBIT' && payload.fundsStatus !== 'REFUNDED') {
      // Calculer le solde disponible actuel depuis les ledger entries AVAILABLE
      const currentBalanceResult = await db
        .from('ledger_entries')
        .where('wallet_id', payload.walletId)
        .where('funds_status', 'AVAILABLE')
        .select(db.raw(`
          COALESCE(
            SUM(CASE WHEN direction = 'CREDIT' THEN amount::numeric ELSE -amount::numeric END),
            0
          ) as balance
        `))
        .first()

      const currentBalance = Number(currentBalanceResult?.balance || 0)
      const projectedBalance = currentBalance - payload.amount

      if (!payload.allowOverdraft && projectedBalance < -wallet.overdraftLimit) {
        throw new Error(
          `Solde insuffisant. Solde disponible: ${currentBalance} XOF, Découvert autorisé: ${wallet.overdraftLimit} XOF`
        )
      }
    }

    // Créer l'entrée ledger (les soldes sont maintenant calculés dynamiquement)
    const entry = await LedgerEntry.create(
      {
        walletId: payload.walletId,
        transactionGroupId: payload.transactionGroupId,
        amount: payload.amount,
        direction: payload.direction,
        category: payload.category,
        label: payload.label,
        sourceSystem: payload.sourceSystem,
        externalReference: payload.externalReference,
        metadata: payload.metadata ?? {},
        fundsStatus: payload.fundsStatus,
        releaseScheduledAt: payload.releaseDelayHours ? DateTime.now().plus({ hours: payload.releaseDelayHours }) : null,
      },
      { client: trx }
    )

    // Note: On ne modifie plus balanceAccounting et balanceAvailable
    // Ils sont maintenant calculés dynamiquement depuis les ledger entries

    return entry
  }

  public async recordEntry(payload: RecordEntryPayload, client?: TransactionClientContract) {
    if (client) {
      return this.persistEntry(payload, client)
    }
    return db.transaction(async (trx) => this.persistEntry(payload, trx))
  }

  public async releaseHold(entryId: string) {
    return db.transaction(async (trx) => {
      const entry = await LedgerEntry.query({ client: trx }).where('id', entryId).forUpdate().firstOrFail()
      if (entry.fundsStatus !== 'ON_HOLD') {
        return entry
      }

      // Changer le statut : ON_HOLD => AVAILABLE
      // Les soldes sont maintenant calculés dynamiquement, donc pas besoin de modifier le wallet
      entry.fundsStatus = 'AVAILABLE'
      entry.releasedAt = DateTime.now()
      await entry.save()

      return entry
    })
  }

  public async confirmPayout(externalReference: string, metadata: Record<string, any>) {
    return db.transaction(async (trx) => {
      const entry = await LedgerEntry.query({ client: trx })
        .where('external_reference', externalReference)
        .where('category', 'PAYOUT')
        .forUpdate()
        .firstOrFail()

      entry.fundsStatus = 'AVAILABLE'
      entry.metadata = {
        ...(entry.metadata || {}),
        payout_confirmation: metadata,
      }
      await entry.save()
      return entry
    })
  }

  public async rollbackPayout(externalReference: string, metadata: Record<string, any>) {
    return db.transaction(async (trx) => {
      const entry = await LedgerEntry.query({ client: trx })
        .where('external_reference', externalReference)
        .where('category', 'PAYOUT')
        .forUpdate()
        .firstOrFail()

      if (entry.fundsStatus === 'FAILED') {
        return entry
      }

      // Changer le statut : LOCKED/AVAILABLE => FAILED
      // Les soldes sont maintenant calculés dynamiquement, donc pas besoin de modifier le wallet
      // FAILED n'est pas comptabilisé dans balanceAccounting ni balanceAvailable
      entry.fundsStatus = 'FAILED'
      entry.metadata = {
        ...(entry.metadata || {}),
        payout_failure: metadata,
      }
      await entry.save()

      return entry
    })
  }

  /**
   * Annule une entrée ledger (utilisé pour les refunds partiels)
   * Change le statut à CANCELED (les soldes sont maintenant calculés dynamiquement)
   */
  public async cancelEntry(
    entryId: string,
    reason: string,
    newEntryId?: string,
    client?: TransactionClientContract
  ) {
    const cancel = async (trx: TransactionClientContract) => {
      const entry = await LedgerEntry.query({ client: trx }).where('id', entryId).forUpdate().firstOrFail()

      if (entry.fundsStatus === 'CANCELED') {
        return entry
      }

      // Mettre à jour l'entrée : changer le statut à CANCELED
      // Les soldes sont maintenant calculés dynamiquement, donc pas besoin de modifier le wallet
      // CANCELED n'est pas comptabilisé dans balanceAccounting ni balanceAvailable
      const statusHistory = entry.metadata?.status_history || []
      statusHistory.push({
        status: 'CANCELED',
        timestamp: DateTime.now().toISO(),
        reason,
        new_entry_id: newEntryId,
      })

      entry.fundsStatus = 'CANCELED'
      entry.metadata = {
        ...(entry.metadata || {}),
        canceled_reason: reason,
        canceled_at: DateTime.now().toISO(),
        next_entry_id: newEntryId, // ID du nouveau ledger (ON_HOLD/LOCKED restant)
        refund_entry_id: undefined, // Sera mis à jour par l'appelant si nécessaire
        status_history: statusHistory,
      }

      await entry.save()

      return entry
    }

    if (client) {
      return cancel(client)
    }
    return db.transaction(async (trx) => cancel(trx))
  }
}

export default new LedgerService()

