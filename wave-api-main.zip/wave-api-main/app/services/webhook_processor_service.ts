import crypto from 'node:crypto'
import env from '#start/env'
import logger from '@adonisjs/core/services/logger'
import WebhookEvent from '#models/webhook_event'
import paymentOrchestrator from '#services/payment_orchestrator_service'

class WebhookProcessorService {
  private secret = env.get('WAVE_WEBHOOK_SECRET')

  public verifySignature(rawBody: string, signatureHeader: string) {
    logger.info('[WebhookProcessor] ===== DEBUT VERIFY SIGNATURE =====')
    logger.info({ hasSecret: !!this.secret, signatureHeaderLength: signatureHeader?.length, rawBodyLength: rawBody?.length }, '[WebhookProcessor] Paramètres reçus')
    
    if (!this.secret || !signatureHeader) {
      logger.warn({ hasSecret: !!this.secret, hasSignatureHeader: !!signatureHeader }, '[WebhookProcessor] Secret ou signature manquant - REJET')
      return false
    }

    // Étape 1: Parser le header Wave-Signature (format: t=<timestamp>,v1=<signature1>,v1=<signature2>...)
    logger.info('[WebhookProcessor] Étape 1: Parsing de la signature header')
    const parts = signatureHeader.split(',')
    let timestamp = ''
    const signatures: string[] = []

    for (const part of parts) {
      const [key, value] = part.split('=')
      if (key === 't') {
        timestamp = value
      } else if (key === 'v1') {
        signatures.push(value)
      }
    }

    logger.info({ timestamp, signaturesCount: signatures.length, signaturesPreview: signatures.map(s => s.substring(0, 20)) }, '[WebhookProcessor] Signature parsée')

    if (!timestamp || signatures.length === 0) {
      logger.warn({ timestamp, signaturesCount: signatures.length }, '[WebhookProcessor] Format de signature invalide - REJET')
      return false
    }

    // Étape 2: Construire le payload (timestamp + rawBody selon la doc Wave)
    logger.info('[WebhookProcessor] Étape 2: Construction du payload (timestamp + rawBody)')
    const payload = timestamp + rawBody
    logger.info({ payloadLength: payload.length, timestampLength: timestamp.length, rawBodyLength: rawBody.length }, '[WebhookProcessor] Payload construit')

    // Étape 3: Calculer la signature attendue
    logger.info('[WebhookProcessor] Étape 3: Calcul de la signature attendue')
    const expected = crypto.createHmac('sha256', this.secret).update(payload).digest('hex')
    logger.info({ expectedLength: expected.length, expectedPreview: expected.substring(0, 20) }, '[WebhookProcessor] Signature attendue calculée')

    // Étape 4: Vérifier si une des signatures correspond
    logger.info('[WebhookProcessor] Étape 4: Comparaison avec les signatures reçues')
    const isValid = signatures.some((received) => {
      if (received.length !== expected.length) {
        logger.debug({ receivedLength: received.length, expectedLength: expected.length }, '[WebhookProcessor] Longueurs différentes pour cette signature')
        return false
      }
      try {
        return crypto.timingSafeEqual(Buffer.from(received), Buffer.from(expected))
      } catch (error) {
        logger.warn({ err: error }, '[WebhookProcessor] Erreur lors de la comparaison')
        return false
      }
    })

    logger.info({ isValid, checkedSignatures: signatures.length }, '[WebhookProcessor] ===== FIN VERIFY SIGNATURE =====')
    return isValid
  }

  public async processEvent(waveEventId: string, type: string, payload: any) {
    logger.info('[WebhookProcessor] ===== DEBUT PROCESS EVENT =====')
    logger.info({ waveEventId, type, payloadKeys: Object.keys(payload || {}) }, '[WebhookProcessor] Paramètres reçus')
    
    let eventModel: WebhookEvent | undefined
    try {
      logger.info('[WebhookProcessor] Étape 1: Création de l\'entrée WebhookEvent en base')
      eventModel = await WebhookEvent.create({
        waveEventId,
        type,
        payload,
        status: 'PENDING',
      })
      logger.info({ eventId: eventModel.id, waveEventId, type }, '[WebhookProcessor] Étape 1: WebhookEvent créé avec succès')
    } catch (error: any) {
      if (error.code === '23505') {
        logger.info({ waveEventId }, '[WebhookProcessor] Étape 1: Événement dupliqué - IGNORÉ')
        return
      }
      logger.error({ waveEventId, err: error }, '[WebhookProcessor] Étape 1: Erreur lors de la création - REJET')
      throw error
    }

    try {
      logger.info({ type, waveEventId }, '[WebhookProcessor] Étape 2: Traitement de l\'événement selon le type')

      switch (type) {
        case 'checkout.session.completed':
          logger.info('[WebhookProcessor] Étape 2: Type checkout.session.completed')
          // payload.data contient directement l'objet Checkout Session
          // payload.data.object n'existe pas dans le format Wave
          const completedSession = payload.data?.object || payload.data || payload
          logger.info({ sessionId: completedSession.id, amount: completedSession.amount, clientReference: completedSession.client_reference }, '[WebhookProcessor] Étape 2: Exécution de l\'intent - va créer les ledger entries')
          await paymentOrchestrator.executeIntent(completedSession.id, completedSession)
          logger.info({ sessionId: completedSession.id }, '[WebhookProcessor] Étape 2: Intent exécuté avec succès - ledger entries créées')
          break
        case 'checkout.session.payment_failed':
          logger.info('[WebhookProcessor] Étape 2: Type checkout.session.payment_failed')
          // payload.data contient directement l'objet Checkout Session
          const failedSession = payload.data?.object || payload.data || payload
          logger.info({ sessionId: failedSession.id, clientReference: failedSession.client_reference }, '[WebhookProcessor] Étape 2: Échec de l\'intent')
          await paymentOrchestrator.failIntent(failedSession.id)
          logger.info({ sessionId: failedSession.id }, '[WebhookProcessor] Étape 2: Intent marqué comme échoué')
          break
        default:
          logger.warn({ type }, '[WebhookProcessor] Étape 2: Type d\'événement non géré - IGNORÉ')
          eventModel.status = 'IGNORED'
          await eventModel.save()
          return
      }

      logger.info('[WebhookProcessor] Étape 3: Marquage de l\'événement comme PROCESSED')
      eventModel.status = 'PROCESSED'
      await eventModel.save()
      logger.info({ eventId: eventModel.id, waveEventId, type }, '[WebhookProcessor] ===== FIN PROCESS EVENT - SUCCÈS =====')
    } catch (error) {
      logger.error({ waveEventId, err: error }, '[WebhookProcessor] Erreur lors du traitement de l\'événement')
      if (eventModel) {
        eventModel.status = 'FAILED'
        eventModel.processingError = (error as Error).message
        await eventModel.save()
        logger.info({ eventId: eventModel.id }, '[WebhookProcessor] Événement marqué comme FAILED')
      }
      throw error
    }
  }
}

export default new WebhookProcessorService()

