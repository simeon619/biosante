import queueService from '#services/queue_service'
import logger from '@adonisjs/core/services/logger'

/**
 * Service pour planifier le job de release automatique des fonds
 * Le job s'exécute toutes les 5 minutes pour libérer les fonds expirés
 */
class ReleaseScheduler {
  private queueName = 'release-holds'
  private jobName = 'release-expired'

  /**
   * Planifie le job récurrent pour libérer automatiquement les fonds expirés
   * S'exécute toutes les 5 minutes
   */
  public async scheduleRecurringJob() {
    try {
      const queue = queueService.getQueue(this.queueName)

      // Vérifier si le job récurrent existe déjà
      const repeatableJobs = await queue.getRepeatableJobs()
      const existingJob = repeatableJobs.find((job) => job.name === this.jobName)

      if (existingJob) {
        logger.info('[ReleaseScheduler] Recurring job already exists')
        return
      }

      // Ajouter le job récurrent (toutes les 5 minutes)
      await queue.add(
        this.jobName,
        {},
        {
          repeat: {
            pattern: '*/5 * * * *', // Toutes les 5 minutes (cron format)
          },
          removeOnComplete: {
            age: 3600, // Garder les jobs complétés pendant 1 heure
            count: 100,
          },
          removeOnFail: {
            age: 86400, // Garder les jobs échoués pendant 24 heures
          },
        }
      )

      logger.info('[ReleaseScheduler] Recurring job scheduled (every 5 minutes)')
    } catch (error: any) {
      logger.error({ error: error.message }, '[ReleaseScheduler] Failed to schedule recurring job')
      throw error
    }
  }

  /**
   * Retire le job récurrent
   */
  public async removeRecurringJob() {
    try {
      const queue = queueService.getQueue(this.queueName)
      const repeatableJobs = await queue.getRepeatableJobs()
      const job = repeatableJobs.find((j) => j.name === this.jobName)

      if (job) {
        await queue.removeRepeatableByKey(job.key)
        logger.info('[ReleaseScheduler] Recurring job removed')
      }
    } catch (error: any) {
      logger.error({ error: error.message }, '[ReleaseScheduler] Failed to remove recurring job')
    }
  }
}

export default new ReleaseScheduler()

