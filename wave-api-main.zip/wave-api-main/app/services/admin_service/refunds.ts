import refundService from '#services/refund_service'

export async function processRefund(data: {
  payment_intent_id: string
  amount: number
  reason: string
  splits: Array<{ wallet_id: string; amount: number }>
  force?: boolean
}) {
  const result = await refundService.processRefund({
    paymentIntentId: data.payment_intent_id,
    amount: data.amount,
    reason: data.reason,
    splits: data.splits,
    force: data.force ?? false,
    sourceSystem: 'ADMIN_DASHBOARD',
  })

  return {
    message: 'Refund effectué avec succès',
    data: result,
  }
}


