import { DateTime } from 'luxon'

/**
 * Génère toutes les dates entre startDate et endDate (inclus)
 */
export function generateDateRange(startDate: string | undefined, endDate: string | undefined): string[] {
  if (!startDate || !endDate) {
    return []
  }

  const start = DateTime.fromISO(startDate).startOf('day')
  const end = DateTime.fromISO(endDate).startOf('day')
  const dates: string[] = []

  let current = start
  while (current <= end) {
    dates.push(current.toISODate()!)
    current = current.plus({ days: 1 })
  }

  return dates
}

/**
 * Normalise une date au format ISO (YYYY-MM-DD)
 */
export function normalizeDate(date: any): string {
  if (!date) return ''

  if (date instanceof Date) {
    return DateTime.fromJSDate(date).toISODate()!
  }

  if (typeof date === 'string') {
    // Essayer ISO d'abord
    let parsed = DateTime.fromISO(date)
    if (parsed.isValid) {
      return parsed.toISODate()!
    }

    // Essayer SQL format
    parsed = DateTime.fromSQL(date)
    if (parsed.isValid) {
      return parsed.toISODate()!
    }

    // Si c'est déjà au format YYYY-MM-DD, le retourner tel quel
    if (/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return date
    }
  }

  return String(date)
}


