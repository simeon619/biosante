import User from '#models/user'
import hash from '@adonisjs/core/services/hash'

export async function generateApiKey(userId: string) {
  const user = await User.find(userId)
  if (!user) {
    throw new Error('User not found')
  }

  const apiKey = `wave_${userId}_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`
  const apiKeyHash = await hash.make(apiKey)

  user.apiKeyHash = apiKeyHash
  await user.save()

  return {
    message: 'API key generated successfully',
    data: {
      user_id: user.id,
      user_email: user.email,
      user_name: user.name,
      api_key: apiKey,
      warning: 'Save this API key - it will not be shown again!',
    },
  }
}

export async function revokeApiKey(userId: string) {
  const user = await User.find(userId)
  if (!user) {
    throw new Error('User not found')
  }

  user.apiKeyHash = null
  await user.save()

  return {
    message: 'API key revoked successfully',
    data: {
      user_id: user.id,
      user_email: user.email,
    },
  }
}

export async function checkApiKey(userId: string) {
  const user = await User.find(userId)
  if (!user) {
    throw new Error('User not found')
  }

  return {
    user_id: user.id,
    user_email: user.email,
    has_api_key: !!user.apiKeyHash,
    is_active: user.isActive,
  }
}

