import { getStats, getUserStats, getWalletStats, getGlobalStats } from './stats.js'
import { getLedgers, getIntents, getWallets, getUsers, getWebhooks } from './collections.js'
import { createUser } from './users.js'
import { createWallet } from './wallets.js'
import { createIntent, getWaveBalance } from './intents.js'
import { generateApiKey, revokeApiKey, checkApiKey } from './api_keys.js'
import { depositWallet, transferWallet, createPayout } from './wallet_operations.js'
import { processRefund } from './refunds.js'

const adminService = {
  getStats,
  getUserStats,
  getWalletStats,
  getGlobalStats,
  getLedgers,
  getIntents,
  getWallets,
  getUsers,
  getWebhooks,
  createUser,
  createWallet,
  createIntent,
  getWaveBalance,
  generateApiKey,
  revokeApiKey,
  checkApiKey,
  depositWallet,
  transferWallet,
  createPayout,
  processRefund,
}

export default adminService

