import db from '@adonisjs/lucid/services/db'
import Wallet from '#models/wallet'
import paymentOrchestrator from '#services/payment_orchestrator_service'
import ledgerService from '#services/ledger_service'
import waveGateway from '#services/wave_gateway_service'
import { generateId } from '#utils/id_generator'

export async function depositWallet(data: {
  wallet_id: string
  amount: number
  currency?: string
  description?: string
  success_url: string
  error_url: string
}) {
  const { wallet_id, amount, currency = 'XOF', description, success_url, error_url } = data

  const wallet = await Wallet.find(wallet_id)
  if (!wallet) {
    throw new Error('Wallet not found')
  }

  if (wallet.isLocked) {
    throw new Error('Wallet is locked')
  }

  const intent = await paymentOrchestrator.initializeIntent({
    amount: Number(amount),
    currency: currency || 'XOF',
    externalReference: `deposit_${wallet.id}_${Date.now()}`,
    sourceSystem: 'DASHBOARD',
    payerId: wallet.ownerId,
    description: description || `Rechargement wallet ${wallet.id} (${wallet.entityType})`,
    successUrl: success_url,
    errorUrl: error_url,
    splits: [
      {
        wallet_id: wallet.id,
        amount: Number(amount),
        category: 'DEPOSIT',
        label: description || `Rechargement compte ${wallet.entityType}`,
        release_delay_hours: 0,
        allow_early_release: false,
      },
    ],
  })

  return {
    message: 'Deposit intent created successfully',
    data: {
      payment_intent_id: intent.id,
      wallet_id: wallet.id,
      wallet_owner: wallet.ownerName || wallet.ownerId,
      wallet_type: wallet.entityType,
      status: intent.status,
      wave_checkout_url: intent.waveCheckoutUrl,
      amount: intent.amount,
      currency: intent.currency,
    },
  }
}

export async function transferWallet(data: {
  from_wallet_id: string
  to_wallet_id: string
  amount: number
  label: string
  category?: string
  external_reference?: string
}) {
  const { from_wallet_id, to_wallet_id, amount, label, category, external_reference } = data

  if (from_wallet_id === to_wallet_id) {
    throw new Error('Les wallets source et destination doivent être différents')
  }

  const validCategories = ['ORDER_PAYMENT', 'SERVICE_PAYMENT', 'COMMISSION', 'ADJUSTMENT', 'SUBSCRIPTION']
  const transferCategory = category || 'ADJUSTMENT'
  if (!validCategories.includes(transferCategory)) {
    throw new Error(`category must be one of: ${validCategories.join(', ')}`)
  }

  await db.transaction(async (trx) => {
    const fromWallet = await Wallet.query({ client: trx }).where('id', from_wallet_id).forUpdate().firstOrFail()

    // Calculer le solde disponible depuis les ledger entries AVAILABLE
    const currentBalance = await fromWallet.calculateBalanceAvailable()
    const newBalance = currentBalance - Number(amount)
    if (newBalance < -fromWallet.overdraftLimit) {
      throw new Error(
        `Solde insuffisant. Solde disponible: ${currentBalance} XOF, Découvert autorisé: ${fromWallet.overdraftLimit} XOF`
      )
    }

    if (fromWallet.isLocked) {
      throw new Error('Le wallet source est verrouillé')
    }

    const toWallet = await Wallet.query({ client: trx }).where('id', to_wallet_id).forUpdate().firstOrFail()

    if (toWallet.isLocked) {
      throw new Error('Le wallet destination est verrouillé')
    }

    if (fromWallet.currency !== toWallet.currency) {
      throw new Error(`Les wallets doivent avoir la même devise. Source: ${fromWallet.currency}, Destination: ${toWallet.currency}`)
    }

    const txGroup = generateId('tx')
    const externalRef = external_reference || `transfer_${txGroup}`

    await ledgerService.recordEntry(
      {
        walletId: fromWallet.id,
        transactionGroupId: txGroup,
        amount: Number(amount),
        direction: 'DEBIT',
        category: transferCategory as any,
        label: label,
        sourceSystem: 'DASHBOARD',
        externalReference: externalRef,
        metadata: {
          transfer_type: 'OUT',
          to_wallet_id: toWallet.id,
          to_wallet_owner: toWallet.ownerName || toWallet.ownerId,
          admin_transfer: true,
        },
        fundsStatus: 'AVAILABLE',
      },
      trx
    )

    await ledgerService.recordEntry(
      {
        walletId: toWallet.id,
        transactionGroupId: txGroup,
        amount: Number(amount),
        direction: 'CREDIT',
        category: transferCategory as any,
        label: label,
        sourceSystem: 'DASHBOARD',
        externalReference: externalRef,
        metadata: {
          transfer_type: 'IN',
          from_wallet_id: fromWallet.id,
          from_wallet_owner: fromWallet.ownerName || fromWallet.ownerId,
          admin_transfer: true,
        },
        fundsStatus: 'AVAILABLE',
      },
      trx
    )
  })

  return {
    message: 'Transfert effectué avec succès',
    data: {
      from_wallet_id,
      to_wallet_id,
      amount: Number(amount),
      currency: 'XOF',
    },
  }
}

export async function createPayout(data: {
  wallet_id: string
  amount: number
  recipient_phone: string
  recipient_name: string
  external_reference?: string
  label?: string
}) {
  const { wallet_id, amount, recipient_phone, recipient_name, external_reference, label } = data

  const phoneRegex = /^\+\d{1,4} \d{6,15}$/
  if (!phoneRegex.test(recipient_phone)) {
    throw new Error('recipient_phone must be in format "+indicatif espace numéro" (e.g., "+225 0759020515")')
  }

  const wallet = await Wallet.find(wallet_id)
  if (!wallet) {
    throw new Error('Wallet not found')
  }

  // Calculer le solde disponible depuis les ledger entries AVAILABLE
  const currentBalance = await wallet.calculateBalanceAvailable()
  if (currentBalance < amount) {
    throw new Error('Solde insuffisant')
  }

  const result = await db.transaction(async (trx) => {
    const walletLocked = await Wallet.query({ client: trx }).where('id', wallet_id).forUpdate().firstOrFail()

    // Re-vérifier le solde dans la transaction
    const lockedBalance = await walletLocked.calculateBalanceAvailable()
    if (lockedBalance < amount) {
      throw new Error('Solde insuffisant')
    }

    const txGroup = generateId('po')
    const ledgerEntry = await ledgerService.recordEntry(
      {
        walletId: wallet_id,
        transactionGroupId: txGroup,
        amount: Number(amount),
        direction: 'DEBIT',
        category: 'PAYOUT',
        label: label || 'Payout',
        sourceSystem: 'DASHBOARD',
        externalReference: external_reference || txGroup,
        metadata: { beneficiary: recipient_phone },
        fundsStatus: 'LOCKED',
      },
      trx
    )

    const payout = await waveGateway.sendPayout({
      amount: Number(amount),
      recipientPhone: recipient_phone,
      recipientName: recipient_name,
      reference: external_reference || txGroup,
    })

    // Les soldes sont maintenant calculés dynamiquement, donc pas besoin de modifier le wallet
    if (payout.status === 'succeeded') {
      ledgerEntry.fundsStatus = 'AVAILABLE'
    } else if (payout.status === 'failed') {
      // Si le payout échoue, changer le statut à FAILED
      // FAILED n'est pas comptabilisé dans les soldes (calculés dynamiquement)
      ledgerEntry.fundsStatus = 'FAILED'
    }

    ledgerEntry.metadata = {
      ...(ledgerEntry.metadata || {}),
      wave_payout_id: payout.id,
      wave_payout_fee: payout.fee,
      wave_payout_status: payout.status,
      wave_payout_timestamp: payout.timestamp,
    }
    await ledgerEntry.save()

    return { ledgerEntry, payout }
  })

  return {
    message: 'Payout initié',
    data: {
      ledger_entry_id: result.ledgerEntry.id,
      payout: {
        id: result.payout.id,
        currency: result.payout.currency,
        receive_amount: result.payout.receive_amount,
        fee: result.payout.fee,
        mobile: result.payout.mobile,
        name: result.payout.name,
        status: result.payout.status,
        timestamp: result.payout.timestamp,
      },
    },
  }
}


