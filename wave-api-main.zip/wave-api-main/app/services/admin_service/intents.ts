import paymentOrchestrator from '#services/payment_orchestrator_service'
import waveGateway from '#services/wave_gateway_service'

export async function createIntent(payload: any) {
  const intent = await paymentOrchestrator.initializeIntent({
    amount: payload.amount,
    currency: payload.currency,
    externalReference: payload.external_reference,
    sourceSystem: payload.source_system,
    payerId: payload.payer_id,
    description: payload.description,
    successUrl: payload.success_url,
    errorUrl: payload.error_url,
    aggregatedMerchantId: payload.aggregated_merchant_id,
    splits: payload.splits as any,
  })

  return {
    message: 'Payment intent created successfully',
    intent: {
      id: intent.id,
      status: intent.status,
      waveCheckoutUrl: intent.waveCheckoutUrl,
      waveSessionId: intent.waveSessionId,
      amount: intent.amount,
      currency: intent.currency,
    },
  }
}

export async function getWaveBalance() {
  return await waveGateway.getBalance()
}


