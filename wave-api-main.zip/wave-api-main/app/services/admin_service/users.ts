import db from '@adonisjs/lucid/services/db'
import User from '#models/user'
import Wallet from '#models/wallet'

export async function createUser(data: { name?: string; email: string; password: string; website?: string }) {
  const { name, email, password, website } = data

  const existingUser = await User.findBy('email', email)
  if (existingUser) {
    throw new Error('Email already exists')
  }

  const trx = await db.transaction()
  try {
    const user = new User()
    user.name = name || null
    user.email = email
    user.password = password
    user.apiKeyHash = null
    user.isActive = true
    user.webhookUrl = null
    user.website = website || null
    user.useTransaction(trx)
    await user.save()

    const mainWallet = new Wallet()
    mainWallet.managerId = user.id
    mainWallet.ownerId = user.id
    mainWallet.entityType = 'PLATFORM'
    // Note: balanceAccounting et balanceAvailable sont maintenant calculés dynamiquement
    // On les initialise à 0 pour satisfaire la contrainte NOT NULL en base
    ;(mainWallet as any)._balanceAccounting = 0
    ;(mainWallet as any)._balanceAvailable = 0
    mainWallet.overdraftLimit = 1000000000
    mainWallet.currency = 'XOF'
    mainWallet.isLocked = false
    mainWallet.ownerName = name || email
    mainWallet.ownerWavePhone = null
    mainWallet.useTransaction(trx)
    await mainWallet.save()
    
    // Calculer les soldes après la création (sera 0 car pas encore de ledger entries)
    await mainWallet.calculateBalanceAccounting()
    await mainWallet.calculateBalanceAvailable()

    user.mainWalletId = mainWallet.id
    await user.save()

    await trx.commit()
    await user.load('mainWallet')

    return {
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        isActive: user.isActive,
        mainWalletId: user.mainWalletId,
        website: user.website,
        createdAt: user.createdAt,
      },
      mainWallet: {
        id: mainWallet.id,
        entityType: mainWallet.entityType,
        balanceAccounting: mainWallet.balanceAccounting,
        balanceAvailable: mainWallet.balanceAvailable,
        currency: mainWallet.currency,
      },
    }
  } catch (error) {
    await trx.rollback()
    throw error
  }
}


