import db from '@adonisjs/lucid/services/db'
import LedgerEntry from '#models/ledger_entry'
import PaymentIntent from '#models/payment_intent'
import Wallet from '#models/wallet'
import User from '#models/user'
import WebhookEvent from '#models/webhook_event'
import { generateDateRange, normalizeDate } from './utils.js'

export async function getStats(filters: {
  start_date?: string
  end_date?: string
  wallet_id?: string
  manager_id?: string
}) {
  const { start_date, end_date, wallet_id, manager_id } = filters

  const query = db.from('ledger_entries').select('direction').select(db.raw('SUM(amount::numeric) as total_amount')).groupBy('direction')

  if (start_date) {
    query.where('created_at', '>=', `${start_date} 00:00:00`)
  }
  if (end_date) {
    query.where('created_at', '<=', `${end_date} 23:59:59`)
  }

  if (wallet_id) {
    query.where('wallet_id', wallet_id)
  } else if (manager_id) {
    query.whereIn('wallet_id', (sub) => sub.select('id').from('wallets').where('manager_id', manager_id))
  }

  const rows = await query
  const stats = { in: 0, out: 0, net: 0 }
  for (const row of rows) {
    const amount = Number(row.total_amount)
    if (row.direction === 'CREDIT') stats.in = amount
    if (row.direction === 'DEBIT') stats.out = amount
  }
  stats.net = stats.in - stats.out

  return {
    scope: wallet_id ? 'WALLET' : manager_id ? 'MANAGER' : 'GLOBAL',
    period: { start: start_date || 'ALL', end: end_date || 'ALL' },
    stats,
  }
}

export async function getUserStats(userId: string, filters: { start_date?: string; end_date?: string }) {
  const { start_date, end_date } = filters

  const globalQuery = db
    .from('ledger_entries')
    .select('direction')
    .select(db.raw('SUM(amount::numeric) as total_amount'))
    .whereIn('wallet_id', (sub) => sub.select('id').from('wallets').where('manager_id', userId))
    .groupBy('direction')

  if (start_date) {
    globalQuery.where('created_at', '>=', `${start_date} 00:00:00`)
  }
  if (end_date) {
    globalQuery.where('created_at', '<=', `${end_date} 23:59:59`)
  }

  const globalRows = await globalQuery
  const globalStats = { in: 0, out: 0, net: 0 }
  for (const row of globalRows) {
    const amount = Number(row.total_amount)
    if (row.direction === 'CREDIT') globalStats.in = amount
    if (row.direction === 'DEBIT') globalStats.out = amount
  }
  globalStats.net = globalStats.in - globalStats.out

  const dailyQuery = db
    .from('ledger_entries')
    .select(db.raw('DATE(created_at) as date'))
    .select('direction')
    .select(db.raw('SUM(amount::numeric) as total_amount'))
    .whereIn('wallet_id', (sub) => sub.select('id').from('wallets').where('manager_id', userId))
    .groupByRaw('DATE(created_at), direction')
    .orderBy('date', 'asc')

  if (start_date) {
    dailyQuery.where('created_at', '>=', `${start_date} 00:00:00`)
  }
  if (end_date) {
    dailyQuery.where('created_at', '<=', `${end_date} 23:59:59`)
  }

  const dailyRows = await dailyQuery
  const dailyData: Record<string, { in: number; out: number }> = {}
  for (const row of dailyRows) {
    const date = normalizeDate(row.date)
    if (!dailyData[date]) {
      dailyData[date] = { in: 0, out: 0 }
    }
    const amount = Number(row.total_amount)
    if (row.direction === 'CREDIT') dailyData[date].in = amount
    if (row.direction === 'DEBIT') dailyData[date].out = amount
  }

  const allDates = generateDateRange(start_date, end_date)
  const daily = allDates.map((date) => {
    const data = dailyData[date] || { in: 0, out: 0 }
    return {
      date,
      in: data.in,
      out: data.out,
      net: data.in - data.out,
    }
  })

  const user = await User.find(userId)
  const wallets = await Wallet.query().where('manager_id', userId)

  return {
    user: user
      ? {
          id: user.id,
          name: user.name,
          email: user.email,
          isActive: user.isActive,
          mainWalletId: user.mainWalletId,
          website: user.website,
          createdAt: user.createdAt,
        }
      : null,
    wallets: wallets.map((w) => ({
      id: w.id,
      ownerId: w.ownerId,
      ownerName: w.ownerName,
      ownerWavePhone: w.ownerWavePhone,
      entityType: w.entityType,
      balanceAccounting: w.balanceAccounting,
      balanceAvailable: w.balanceAvailable,
      currency: w.currency,
      isLocked: w.isLocked,
      createdAt: w.createdAt,
    })),
    stats: globalStats,
    daily,
  }
}

export async function getWalletStats(walletId: string, filters: { start_date?: string; end_date?: string }) {
  const { start_date, end_date } = filters

  // Utiliser le query builder Lucid avec db.raw() pour SUM
  const globalQuery = db
    .from('ledger_entries')
    .select('direction')
    .select(db.raw('SUM(amount::numeric) as total_amount'))
    .where('wallet_id', walletId)
    .groupBy('direction')

  if (start_date) {
    // Ajouter le début de la journée pour inclure toutes les entrées du jour
    globalQuery.where('created_at', '>=', `${start_date} 00:00:00`)
  }
  if (end_date) {
    // Ajouter la fin de la journée pour inclure toutes les entrées du jour
    globalQuery.where('created_at', '<=', `${end_date} 23:59:59`)
  }

  const globalRows = await globalQuery
  const globalStats = { in: 0, out: 0, net: 0 }
  
  for (const row of globalRows) {
    const amount = Number(row.total_amount || 0)
    if (row.direction === 'CREDIT') globalStats.in = amount
    if (row.direction === 'DEBIT') globalStats.out = amount
  }
  globalStats.net = globalStats.in - globalStats.out

  // Requête SQL pour les stats quotidiennes
  const dailyQuery = db
    .from('ledger_entries')
    .select(db.raw('DATE(created_at) as date'))
    .select('direction')
    .select(db.raw('SUM(amount::numeric) as total_amount'))
    .where('wallet_id', walletId)
    .groupByRaw('DATE(created_at), direction')
    .orderBy('date', 'asc')

  if (start_date) {
    // Ajouter le début de la journée pour inclure toutes les entrées du jour
    dailyQuery.where('created_at', '>=', `${start_date} 00:00:00`)
  }
  if (end_date) {
    // Ajouter la fin de la journée pour inclure toutes les entrées du jour
    dailyQuery.where('created_at', '<=', `${end_date} 23:59:59`)
  }

  const dailyRows = await dailyQuery
  
  const dailyData: Record<string, { in: number; out: number }> = {}
  for (const row of dailyRows) {
    const date = normalizeDate(row.date)
    if (!dailyData[date]) {
      dailyData[date] = { in: 0, out: 0 }
    }
    const amount = Number(row.total_amount || 0)
    if (row.direction === 'CREDIT') dailyData[date].in = amount
    if (row.direction === 'DEBIT') dailyData[date].out = amount
  }

  const allDates = generateDateRange(start_date, end_date)
  const daily = allDates.map((date) => {
    const data = dailyData[date] || { in: 0, out: 0 }
    return {
      date,
      in: data.in,
      out: data.out,
      net: data.in - data.out,
    }
  })

  const wallet = await Wallet.query().where('id', walletId).preload('manager').first()

  const intents = await PaymentIntent.query().where('payer_id', walletId).orderBy('created_at', 'desc').limit(100)

  const ledgers = await LedgerEntry.query().where('wallet_id', walletId).orderBy('created_at', 'desc').limit(100)

  const intentIds = intents.map((i) => i.id)
  let webhooks: WebhookEvent[] = []
  if (intentIds.length > 0) {
    const allWebhooks = await WebhookEvent.query().orderBy('created_at', 'desc').limit(500)

    webhooks = allWebhooks
      .filter((w) => {
        try {
          const payload = typeof w.payload === 'string' ? JSON.parse(w.payload) : w.payload
          return intentIds.includes(payload?.payment_intent_id || payload?.session_id || '')
        } catch {
          return false
        }
      })
      .slice(0, 100)
  }

  return {
    wallet: wallet
      ? {
          id: wallet.id,
          managerId: wallet.managerId,
          ownerId: wallet.ownerId,
          ownerName: wallet.ownerName,
          ownerWavePhone: wallet.ownerWavePhone,
          entityType: wallet.entityType,
          balanceAccounting: wallet.balanceAccounting,
          balanceAvailable: wallet.balanceAvailable,
          overdraftLimit: wallet.overdraftLimit,
          currency: wallet.currency,
          isLocked: wallet.isLocked,
          createdAt: wallet.createdAt,
          manager: wallet.manager
            ? {
                id: wallet.manager.id,
                name: wallet.manager.name,
                email: wallet.manager.email,
                website: wallet.manager.website,
              }
            : null,
        }
      : null,
    stats: globalStats,
    daily,
    intents: intents.map((i) => ({
      id: i.id,
      externalReference: i.externalReference,
      amount: i.amount,
      currency: i.currency,
      status: i.status,
      createdAt: i.createdAt,
    })),
    ledgers: ledgers.map((l) => ({
      id: l.id,
      amount: l.amount,
      direction: l.direction,
      category: l.category,
      label: l.label,
      fundsStatus: l.fundsStatus,
      createdAt: l.createdAt,
    })),
    webhooks: webhooks.map((w) => ({
      id: w.id,
      waveEventId: w.waveEventId,
      type: w.type,
      status: w.status,
      createdAt: w.createdAt,
    })),
  }
}

export async function getGlobalStats(filters: { start_date?: string; end_date?: string }) {
  const { start_date, end_date } = filters

  const userCount = await db.from('users').count('* as total').first()
  const walletCount = await db.from('wallets').count('* as total').first()
  const intentCount = await db.from('payment_intents').count('* as total').first()
  const ledgerCount = await db.from('ledger_entries').count('* as total').first()
  const webhookCount = await db.from('webhook_events').count('* as total').first()

  const query = db.from('ledger_entries').select('direction').select(db.raw('SUM(amount::numeric) as total_amount')).groupBy('direction')
  if (start_date) {
    query.where('created_at', '>=', `${start_date} 00:00:00`)
  }
  if (end_date) {
    query.where('created_at', '<=', `${end_date} 23:59:59`)
  }

  const rows = await query
  const stats = { in: 0, out: 0, net: 0 }
  for (const row of rows) {
    const amount = Number(row.total_amount)
    if (row.direction === 'CREDIT') stats.in = amount
    if (row.direction === 'DEBIT') stats.out = amount
  }
  stats.net = stats.in - stats.out

  const dailyQuery = db
    .from('ledger_entries')
    .select(db.raw('DATE(created_at) as date'))
    .select('direction')
    .select(db.raw('SUM(amount::numeric) as total_amount'))
    .groupByRaw('DATE(created_at), direction')
    .orderBy('date', 'asc')

  if (start_date) {
    dailyQuery.where('created_at', '>=', `${start_date} 00:00:00`)
  }
  if (end_date) {
    dailyQuery.where('created_at', '<=', `${end_date} 23:59:59`)
  }

  const dailyRows = await dailyQuery
  const dailyData: Record<string, { in: number; out: number }> = {}
  for (const row of dailyRows) {
    const date = normalizeDate(row.date)
    if (!dailyData[date]) {
      dailyData[date] = { in: 0, out: 0 }
    }
    const amount = Number(row.total_amount)
    if (row.direction === 'CREDIT') dailyData[date].in = amount
    if (row.direction === 'DEBIT') dailyData[date].out = amount
  }

  const allDates = generateDateRange(start_date, end_date)
  const daily = allDates.map((date) => {
    const data = dailyData[date] || { in: 0, out: 0 }
    return {
      date,
      in: data.in,
      out: data.out,
      net: data.in - data.out,
    }
  })

  return {
    counts: {
      users: Number((userCount as any)?.total || 0),
      wallets: Number((walletCount as any)?.total || 0),
      intents: Number((intentCount as any)?.total || 0),
      ledgers: Number((ledgerCount as any)?.total || 0),
      webhooks: Number((webhookCount as any)?.total || 0),
    },
    stats,
    daily,
  }
}

