import User from '#models/user'
import Wallet from '#models/wallet'

export async function createWallet(data: {
  manager_id: string
  owner_id: string
  owner_name?: string
  owner_wave_phone?: string
  entity_type: 'DRIVER' | 'VENDOR' | 'CLIENT' | 'PLATFORM'
  currency?: string
  overdraft_limit?: number
}) {
  const { manager_id, owner_id, owner_name, owner_wave_phone, entity_type, currency, overdraft_limit } = data

  const manager = await User.find(manager_id)
  if (!manager) {
    throw new Error('Manager not found')
  }

  const validEntityTypes = ['DRIVER', 'VENDOR', 'CLIENT', 'PLATFORM']
  if (!validEntityTypes.includes(entity_type)) {
    throw new Error(`entity_type must be one of: ${validEntityTypes.join(', ')}`)
  }

  const phoneRegex = /^\+\d{1,4} \d{6,15}$/
  if (owner_wave_phone && !phoneRegex.test(owner_wave_phone)) {
    throw new Error('owner_wave_phone must be in format "+indicatif espace numéro" (e.g., "+225 0759020515")')
  }

  const wallet = new Wallet()
  wallet.managerId = manager_id
  wallet.ownerId = owner_id
  wallet.ownerName = owner_name || null
  wallet.ownerWavePhone = owner_wave_phone || null
  wallet.entityType = entity_type
  wallet.currency = currency || 'XOF'
  wallet.overdraftLimit = overdraft_limit || 0
  // Note: balanceAccounting et balanceAvailable sont maintenant calculés dynamiquement
  // On les initialise à 0 pour satisfaire la contrainte NOT NULL en base
  ;(wallet as any)._balanceAccounting = 0
  ;(wallet as any)._balanceAvailable = 0
  wallet.isLocked = false
  await wallet.save()

  // Calculer les soldes après la création (sera 0 car pas encore de ledger entries)
  await wallet.calculateBalanceAccounting()
  await wallet.calculateBalanceAvailable()

  return {
    id: wallet.id,
    managerId: wallet.managerId,
    ownerId: wallet.ownerId,
    ownerName: wallet.ownerName,
    ownerWavePhone: wallet.ownerWavePhone,
    entityType: wallet.entityType,
    currency: wallet.currency,
    balanceAccounting: wallet.balanceAccounting,
    balanceAvailable: wallet.balanceAvailable,
    overdraftLimit: wallet.overdraftLimit,
    isLocked: wallet.isLocked,
    createdAt: wallet.createdAt,
  }
}


