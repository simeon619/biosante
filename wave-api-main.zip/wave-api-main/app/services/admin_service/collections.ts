import LedgerEntry from '#models/ledger_entry'
import PaymentIntent from '#models/payment_intent'
import User from '#models/user'
import Wallet from '#models/wallet'
import WebhookEvent from '#models/webhook_event'

export async function getLedgers(filters: Record<string, any>, page: number = 1, limit: number = 20) {
  const query = LedgerEntry.query().preload('wallet')

  if (filters.id && String(filters.id).trim()) query.where('id', 'like', `%${String(filters.id).trim()}%`)
  if (filters.wallet_id && String(filters.wallet_id).trim())
    query.where('wallet_id', 'like', `%${String(filters.wallet_id).trim()}%`)
  if (filters.direction && String(filters.direction).trim()) query.where('direction', String(filters.direction).trim())
  if (filters.category && String(filters.category).trim()) query.where('category', String(filters.category).trim())
  if (filters.date_from && String(filters.date_from).trim()) query.where('created_at', '>=', String(filters.date_from).trim())
  if (filters.date_to && String(filters.date_to).trim()) query.where('created_at', '<=', String(filters.date_to).trim())

  query.orderBy('created_at', 'desc')
  return await query.paginate(page, limit)
}

export async function getIntents(filters: Record<string, any>, page: number = 1, limit: number = 20) {
  const query = PaymentIntent.query()

  if (filters.id && String(filters.id).trim()) query.where('id', 'like', `%${String(filters.id).trim()}%`)
  if (filters.status && String(filters.status).trim()) query.where('status', String(filters.status).trim())
  if (filters.external_reference && String(filters.external_reference).trim())
    query.where('external_reference', 'like', `%${String(filters.external_reference).trim()}%`)
  if (filters.wave_session_id && String(filters.wave_session_id).trim())
    query.where('wave_session_id', 'like', `%${String(filters.wave_session_id).trim()}%`)
  if (filters.payer_id && String(filters.payer_id).trim()) query.where('payer_id', 'like', `%${String(filters.payer_id).trim()}%`)
  if (filters.date_from && String(filters.date_from).trim()) query.where('created_at', '>=', String(filters.date_from).trim())
  if (filters.date_to && String(filters.date_to).trim()) query.where('created_at', '<=', String(filters.date_to).trim())

  query.orderBy('created_at', 'desc')
  return await query.paginate(page, limit)
}

export async function getWallets(filters: Record<string, any>, page: number = 1, limit: number = 20) {
  const query = Wallet.query().preload('manager')

  const walletsSearch = filters.search && String(filters.search).trim()
  if (walletsSearch) {
    query.where((builder) => {
      builder
        .whereILike('id', `%${walletsSearch}%`)
        .orWhereILike('owner_id', `%${walletsSearch}%`)
        .orWhereILike('manager_id', `%${walletsSearch}%`)
        .orWhereILike('owner_name', `%${walletsSearch}%`)
        .orWhereILike('owner_wave_phone', `%${walletsSearch}%`)
    })
  }

  if (filters.id && String(filters.id).trim()) query.whereILike('id', `%${String(filters.id).trim()}%`)
  if (filters.owner_id && String(filters.owner_id).trim()) query.whereILike('owner_id', `%${String(filters.owner_id).trim()}%`)
  if (filters.owner_name && String(filters.owner_name).trim())
    query.whereILike('owner_name', `%${String(filters.owner_name).trim()}%`)
  if (filters.owner_wave_phone && String(filters.owner_wave_phone).trim())
    query.whereILike('owner_wave_phone', `%${String(filters.owner_wave_phone).trim()}%`)
  if (filters.manager_id && String(filters.manager_id).trim()) query.whereILike('manager_id', `%${String(filters.manager_id).trim()}%`)
  if (filters.entity_type && String(filters.entity_type).trim()) query.where('entity_type', String(filters.entity_type).trim())

  query.orderBy('created_at', 'desc')
  const paginationResult = await query.paginate(page, limit)

  const wallets = paginationResult.all().map((wallet) => ({
    id: wallet.id,
    managerId: wallet.managerId,
    ownerId: wallet.ownerId,
    ownerName: wallet.ownerName,
    ownerWavePhone: wallet.ownerWavePhone,
    entityType: wallet.entityType,
    balanceAccounting: wallet.balanceAccounting,
    balanceAvailable: wallet.balanceAvailable,
    overdraftLimit: wallet.overdraftLimit,
    currency: wallet.currency,
    isLocked: wallet.isLocked,
    createdAt: wallet.createdAt,
    manager: wallet.manager
      ? {
          id: wallet.manager.id,
          name: wallet.manager.name,
          email: wallet.manager.email,
          website: wallet.manager.website,
        }
      : null,
  }))

  return {
    data: wallets,
    meta: paginationResult.getMeta(),
  }
}

export async function getUsers(filters: Record<string, any>, page: number = 1, limit: number = 20) {
  const query = User.query().preload('mainWallet')

  const searchValue = filters.search && String(filters.search).trim()
  if (searchValue) {
    query.where((builder) => {
      builder
        .where('id', 'like', `%${searchValue}%`)
        .orWhere('name', 'like', `%${searchValue}%`)
        .orWhere('email', 'like', `%${searchValue}%`)
    })
  }

  if (filters.id && String(filters.id).trim()) query.where('id', 'like', `%${String(filters.id).trim()}%`)
  if (filters.name && String(filters.name).trim()) query.where('name', 'like', `%${String(filters.name).trim()}%`)
  if (filters.email && String(filters.email).trim()) query.where('email', 'like', `%${String(filters.email).trim()}%`)
  if (filters.is_active !== undefined && filters.is_active !== '')
    query.where('is_active', String(filters.is_active).trim() === 'true')

  query.orderBy('created_at', 'desc')
  return await query.paginate(page, limit)
}

export async function getWebhooks(filters: Record<string, any>, page: number = 1, limit: number = 20) {
  if (filters.wallet_id && String(filters.wallet_id).trim()) {
    const walletId = String(filters.wallet_id).trim()
    const intents = await PaymentIntent.query().where('payer_id', walletId).select('id')

    const intentIds = intents.map((i) => i.id)

    if (intentIds.length === 0) {
      return {
        data: [],
        meta: {
          total: 0,
          perPage: limit,
          currentPage: page,
          lastPage: 0,
          firstPage: 1,
        },
      }
    }

    const allWebhooks = await WebhookEvent.query().orderBy('created_at', 'desc').limit(5000)

    const filteredWebhooks = allWebhooks.filter((w) => {
      try {
        const payload = typeof w.payload === 'string' ? JSON.parse(w.payload) : w.payload
        const paymentIntentId = payload?.payment_intent_id || payload?.session_id || ''
        return intentIds.includes(paymentIntentId)
      } catch {
        return false
      }
    })

    let finalWebhooks = filteredWebhooks
    if (filters.id && String(filters.id).trim()) {
      const idFilter = String(filters.id).trim().toLowerCase()
      finalWebhooks = finalWebhooks.filter((w) => w.id.toLowerCase().includes(idFilter))
    }
    if (filters.status && String(filters.status).trim()) {
      finalWebhooks = finalWebhooks.filter((w) => w.status === String(filters.status).trim())
    }
    if (filters.type && String(filters.type).trim()) {
      finalWebhooks = finalWebhooks.filter((w) => w.type === String(filters.type).trim())
    }
    if (filters.wave_event_id && String(filters.wave_event_id).trim()) {
      const eventIdFilter = String(filters.wave_event_id).trim().toLowerCase()
      finalWebhooks = finalWebhooks.filter((w) => w.waveEventId.toLowerCase().includes(eventIdFilter))
    }

    const total = finalWebhooks.length
    const start = (page - 1) * limit
    const end = start + limit
    const paginatedWebhooks = finalWebhooks.slice(start, end)

    return {
      data: paginatedWebhooks.map((w) => ({
        id: w.id,
        waveEventId: w.waveEventId,
        type: w.type,
        payload: w.payload,
        status: w.status,
        processingError: w.processingError,
        createdAt: w.createdAt,
        updatedAt: w.updatedAt,
      })),
      meta: {
        total,
        perPage: limit,
        currentPage: page,
        lastPage: Math.ceil(total / limit),
        firstPage: 1,
      },
    }
  }

  const query = WebhookEvent.query()

  if (filters.id && String(filters.id).trim()) query.where('id', 'like', `%${String(filters.id).trim()}%`)
  if (filters.status && String(filters.status).trim()) query.where('status', String(filters.status).trim())
  if (filters.type && String(filters.type).trim()) query.where('type', String(filters.type).trim())
  if (filters.wave_event_id && String(filters.wave_event_id).trim())
    query.where('wave_event_id', 'like', `%${String(filters.wave_event_id).trim()}%`)

  query.orderBy('created_at', 'desc')
  return await query.paginate(page, limit)
}


