import { DateTime } from 'luxon'
import db from '@adonisjs/lucid/services/db'
import LedgerEntry from '#models/ledger_entry'
import logger from '@adonisjs/core/services/logger'

class ReleaseService {
  /**
   * Libère automatiquement tous les fonds ON_HOLD dont le délai est expiré
   * Note: Les LOCKED ne sont pas libérés automatiquement (gérés par le système pour les payouts)
   * @returns Nombre d'entrées libérées
   */
  public async releaseExpiredHolds(): Promise<number> {
    const now = DateTime.now()
    let releasedCount = 0

    try {
      // Trouver uniquement les entries ON_HOLD avec releaseScheduledAt <= now
      // Les LOCKED sont gérés par le système (payouts) et ne sont pas libérés automatiquement
      const expiredEntries = await LedgerEntry.query()
        .where('funds_status', 'ON_HOLD') // Seulement ON_HOLD
        .whereNotNull('release_scheduled_at')
        .where('release_scheduled_at', '<=', now.toSQL())
        .whereNull('released_at') // Pas déjà libérées
        .limit(100) // Traiter par batch de 100

      if (expiredEntries.length === 0) {
        return 0
      }

      logger.info({ count: expiredEntries.length }, '[ReleaseService] Processing expired ON_HOLD entries')

      // Traiter chaque entry dans une transaction
      for (const entry of expiredEntries) {
        try {
          await db.transaction(async (trx) => {
            // Re-vérifier avec lock pour éviter les doubles releases
            const lockedEntry = await LedgerEntry.query({ client: trx })
              .where('id', entry.id)
              .where('funds_status', 'ON_HOLD') // Seulement ON_HOLD
              .whereNull('released_at')
              .forUpdate()
              .first()

            if (!lockedEntry) {
              return // Déjà traitée par un autre processus
            }

            // Libérer l'entry : ON_HOLD => AVAILABLE
            // Les soldes sont maintenant calculés dynamiquement, donc pas besoin de modifier le wallet
            lockedEntry.fundsStatus = 'AVAILABLE'
            lockedEntry.releasedAt = DateTime.now()

            await lockedEntry.save()

            releasedCount++

            logger.info(
              {
                entryId: lockedEntry.id,
                walletId: lockedEntry.walletId,
                amount: lockedEntry.amount,
                fundsStatus: lockedEntry.fundsStatus,
              },
              '[ReleaseService] Released expired hold'
            )
          })
        } catch (error: any) {
          logger.error({ entryId: entry.id, error: error.message }, '[ReleaseService] Failed to release entry')
          // Continue avec les autres entries même en cas d'erreur
        }
      }

      return releasedCount
    } catch (error: any) {
      logger.error({ error: error.message }, '[ReleaseService] Error in releaseExpiredHolds')
      throw error
    }
  }

  /**
   * Libère un fond ON_HOLD par son ID d'entrée (manuel)
   * Note: Les LOCKED ne peuvent pas être libérés manuellement (gérés uniquement par le système)
   */
  public async releaseHoldById(entryId: string): Promise<LedgerEntry> {
    return db.transaction(async (trx) => {
      const entry = await LedgerEntry.query({ client: trx }).where('id', entryId).forUpdate().firstOrFail()

      // Seuls les ON_HOLD peuvent être libérés manuellement
      if (entry.fundsStatus !== 'ON_HOLD') {
        if (entry.fundsStatus === 'LOCKED') {
          throw new Error(
            `Entry ${entryId} is LOCKED. LOCKED entries are managed by the system and cannot be released manually.`
          )
        }
        throw new Error(`Entry ${entryId} is not ON_HOLD (current status: ${entry.fundsStatus})`)
      }

      if (entry.releasedAt) {
        throw new Error(`Entry ${entryId} has already been released`)
      }

      // Libérer : ON_HOLD => AVAILABLE
      // Les soldes sont maintenant calculés dynamiquement, donc pas besoin de modifier le wallet
      entry.fundsStatus = 'AVAILABLE'
      entry.releasedAt = DateTime.now()
      await entry.save()

      return entry
    })
  }

  /**
   * Libère un fond ON_HOLD par external_reference
   * Si plusieurs entries ont la même référence, toutes sont libérées
   * Note: Les LOCKED ne peuvent pas être libérés manuellement (gérés uniquement par le système)
   */
  public async releaseHoldByReference(externalReference: string): Promise<LedgerEntry[]> {
    return db.transaction(async (trx) => {
      const entries = await LedgerEntry.query({ client: trx })
        .where('external_reference', externalReference)
        .where('funds_status', 'ON_HOLD') // Seulement ON_HOLD
        .whereNull('released_at')
        .forUpdate()

      if (entries.length === 0) {
        throw new Error(`No ON_HOLD entries found for external_reference: ${externalReference}`)
      }

      const releasedEntries: LedgerEntry[] = []

      for (const entry of entries) {
        // Les soldes sont maintenant calculés dynamiquement, donc pas besoin de modifier le wallet
        entry.fundsStatus = 'AVAILABLE'
        entry.releasedAt = DateTime.now()
        await entry.save()

        releasedEntries.push(entry)
      }

      return releasedEntries
    })
  }

  /**
   * Libère un fond ON_HOLD par external_reference et wallet_id (plus précis)
   * Note: Les LOCKED ne peuvent pas être libérés manuellement (gérés uniquement par le système)
   */
  public async releaseHoldByReferenceAndWallet(
    externalReference: string,
    walletId: string
  ): Promise<LedgerEntry> {
    return db.transaction(async (trx) => {
      const entry = await LedgerEntry.query({ client: trx })
        .where('external_reference', externalReference)
        .where('wallet_id', walletId)
        .where('funds_status', 'ON_HOLD') // Seulement ON_HOLD
        .whereNull('released_at')
        .forUpdate()
        .firstOrFail()

      // Libérer : ON_HOLD => AVAILABLE
      // Les soldes sont maintenant calculés dynamiquement, donc pas besoin de modifier le wallet
      entry.fundsStatus = 'AVAILABLE'
      entry.releasedAt = DateTime.now()
      await entry.save()

      return entry
    })
  }
}

export default new ReleaseService()

