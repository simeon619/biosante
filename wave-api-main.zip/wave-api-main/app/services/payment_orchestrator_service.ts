import db from '@adonisjs/lucid/services/db'
import { Exception } from '@adonisjs/core/exceptions'
import logger from '@adonisjs/core/services/logger'
import PaymentIntent, { SplitConfigItem } from '#models/payment_intent'
import waveGateway from '#services/wave_gateway_service'
import ledgerService from '#services/ledger_service'

class PaymentOrchestratorService {
  public async initializeIntent(params: {
    amount: number
    currency: string
    externalReference: string
    sourceSystem: string
    payerId?: string
    description?: string
    successUrl: string
    errorUrl: string
    aggregatedMerchantId?: string
    splits: SplitConfigItem[]
  }) {
    const totalSplit = params.splits.reduce((acc, split) => acc + split.amount, 0)
    if (totalSplit !== params.amount) {
      throw new Exception('Split mismatch', { status: 400, code: 'SPLIT_MISMATCH' })
    }

    const intent = await PaymentIntent.create({
      externalReference: params.externalReference,
      sourceSystem: params.sourceSystem,
      amount: params.amount,
      currency: params.currency,
      payerId: params.payerId,
      description: params.description,
      aggregatedMerchantId: params.aggregatedMerchantId,
      status: 'PENDING',
      splitsConfig: params.splits,
    })

    try {
      const waveSession = await waveGateway.createCheckoutSession({
        amount: params.amount,
        currency: params.currency,
        successUrl: params.successUrl,
        errorUrl: params.errorUrl,
        clientReference: intent.id,
        aggregatedMerchantId: params.aggregatedMerchantId,
      })

      intent.waveSessionId = waveSession.id
      intent.waveCheckoutUrl = waveSession.checkout_url || waveSession.wave_launch_url || null
      intent.status = 'WAVE_CREATED'
      await intent.save()

      logger.info({ intentId: intent.id }, '[PaymentOrchestrator] Intent created')
      return intent
    } catch (error) {
      intent.status = 'FAILED'
      await intent.save()
      throw error
    }
  }

  public async executeIntent(waveSessionId: string, wavePayload: any) {
    const intent = await PaymentIntent.query().where('wave_session_id', waveSessionId).first()
    if (!intent) {
      throw new Exception('Payment intent not found', { status: 404 })
    }
    if (intent.status === 'COMPLETED') {
      return intent
    }

    await db.transaction(async (trx) => {
      const lockedIntent = await PaymentIntent.query({ client: trx }).where('id', intent.id).forUpdate().firstOrFail()
      if (lockedIntent.status === 'COMPLETED') {
        return
      }

      logger.info({ intentId: lockedIntent.id, splitsCount: lockedIntent.splitsConfig.length }, '[PaymentOrchestrator] Début création des ledger entries pour chaque split')
      
      for (const split of lockedIntent.splitsConfig) {
        const delay = Number(split.release_delay_hours || 0)
        const fundsStatus = delay > 0 ? 'ON_HOLD' : 'AVAILABLE'

        logger.info({ 
          intentId: lockedIntent.id, 
          walletId: split.wallet_id, 
          amount: split.amount, 
          fundsStatus, 
          delayHours: delay 
        }, '[PaymentOrchestrator] Création ledger entry pour split')

        const ledgerEntry = await ledgerService.recordEntry(
          {
            walletId: split.wallet_id,
            transactionGroupId: lockedIntent.id,
            amount: split.amount,
            direction: 'CREDIT',
            category: split.category as any,
            label: split.label,
            sourceSystem: lockedIntent.sourceSystem,
            externalReference: split.external_reference || lockedIntent.externalReference,
            metadata: {
              wave_session_id: waveSessionId,
              payment_intent_id: lockedIntent.id,
              payer_phone: wavePayload?.customer_phone,
            },
            fundsStatus,
            releaseDelayHours: delay,
          },
          trx
        )

        logger.info({ 
          intentId: lockedIntent.id, 
          ledgerEntryId: ledgerEntry.id, 
          walletId: split.wallet_id, 
          amount: split.amount 
        }, '[PaymentOrchestrator] Ledger entry créée avec succès')
      }

      lockedIntent.status = 'COMPLETED'
      await lockedIntent.save()
      logger.info({ intentId: lockedIntent.id, splitsProcessed: lockedIntent.splitsConfig.length }, '[PaymentOrchestrator] Intent completed - toutes les ledger entries créées')
    })

    return intent
  }

  public async failIntent(waveSessionId: string) {
    const intent = await PaymentIntent.findBy('wave_session_id', waveSessionId)
    if (intent && intent.status !== 'COMPLETED') {
      intent.status = 'FAILED'
      await intent.save()
    }
    return intent
  }
}

export default new PaymentOrchestratorService()

