import { BaseCommand } from '@adonisjs/core/ace'
import User from '#models/user'
import hash from '@adonisjs/core/services/hash'

export default class GenerateApiKey extends BaseCommand {
  public static commandName = 'generate:api-key'
  public static description = 'Génère une API key pour un utilisateur'

  public static options = {
    startApp: true,
  }

  public async run() {
    const userId = this.parsed.args[0] || await this.prompt.ask('User ID', {
      default: '',
    })

    if (!userId) {
      this.logger.error('User ID is required')
      this.logger.info('Usage: node ace generate:api-key <user_id>')
      return
    }

    const user = await User.find(userId)
    if (!user) {
      this.logger.error(`User ${userId} not found`)
      return
    }

    // Générer une API key
    const apiKey = `wave_${userId}_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`
    const apiKeyHash = await hash.make(apiKey)

    // Mettre à jour l'utilisateur
    user.apiKeyHash = apiKeyHash
    await user.save()

    this.logger.success(`API key generated for user ${user.email}`)
    this.logger.info(`User ID: ${userId}`)
    this.logger.info(`API Key: ${apiKey}`)
    this.logger.warning('⚠️  Save this API key - it will not be shown again!')
  }
}

