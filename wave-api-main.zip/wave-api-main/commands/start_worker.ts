import { BaseCommand } from '@adonisjs/core/ace'
import queueService from '#services/queue_service'
import webhookJob from '#jobs/webhook_job'
import releaseHoldJob from '#jobs/release_hold_job'
import releaseScheduler from '#services/release_scheduler'

export default class StartWorker extends BaseCommand {
  public static commandName = 'worker:start'
  public static description = 'Démarre le worker BullMQ pour traiter les webhooks Wave et les releases automatiques'

  public static options = {
    startApp: true,
  }

  public async run() {
    this.logger.info('Démarrage du worker BullMQ...')
    const { Worker } = await import('bullmq')

    // Worker pour les webhooks
    const webhookWorker = new Worker('wave-webhooks', webhookJob, {
      connection: queueService.getConnection(),
      concurrency: 5,
      limiter: {
        max: 10,
        duration: 1000,
      },
    })

    webhookWorker.on('ready', () => {
      this.logger.success('Worker webhooks prêt et en écoute sur wave-webhooks')
    })

    webhookWorker.on('failed', (job, error) => {
      this.logger.error(`Webhook job ${job?.id} failed: ${error.message}`)
    })

    // Worker pour les releases automatiques
    const releaseWorker = new Worker('release-holds', releaseHoldJob, {
      connection: queueService.getConnection(),
      concurrency: 1, // Un seul job à la fois pour éviter les conflits
      limiter: {
        max: 1,
        duration: 60000, // Max 1 job par minute
      },
    })

    releaseWorker.on('ready', () => {
      this.logger.success('Worker release prêt et en écoute sur release-holds')
    })

    releaseWorker.on('failed', (job, error) => {
      this.logger.error(`Release job ${job?.id} failed: ${error.message}`)
    })

    releaseWorker.on('completed', (job) => {
      this.logger.info(`Release job ${job.id} completed`)
    })

    // Planifier le job récurrent au démarrage
    try {
      await releaseScheduler.scheduleRecurringJob()
      this.logger.success('Job récurrent de release planifié (toutes les 5 minutes)')
    } catch (error: any) {
      this.logger.error(`Impossible de planifier le job récurrent: ${error.message}`)
    }

    await new Promise(() => {})
  }
}

