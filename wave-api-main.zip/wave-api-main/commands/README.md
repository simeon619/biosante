# Commandes Wave API

## seed:admins

Crée les 3 admins avec leurs wallets principaux. Remplace le seeder `admin_seeder.ts`.

```bash
node ace seed:admins
```

**Admins créés :**
- `sublymus@gmail.com` - Admin Sublymus
- `sablymus@gmail.com` - Admin Sablymus  
- `seblymus@gmail.com` - Admin Seblymus

**Mot de passe par défaut :** `admin123` (⚠️ À changer en production)

## simulate:transactions

Simule des transactions pour tous les admins (30-50 transactions par admin sur les 60 derniers jours).

```bash
node ace simulate:transactions
```

**Fonctionnalités :**
- Génère 30-50 transactions par admin
- Réparties sur les 60 derniers jours
- Crée des Payment Intents, Webhook Events et Ledger Entries
- Met à jour les balances des wallets de manière cohérente
- Utilise un tableau minimal de 70 montants prédéfinis pour la cohérence
- Les IDs sont basés sur les vrais IDs en DB pour assurer les relations

**Règles de cohérence :**
1. Les IDs sont générés à partir des vrais IDs en DB (`txn_{user_id}_{wallet_id}_{index}`)
2. Les montants proviennent d'un tableau prédéfini de 70 valeurs réalistes
3. Les statuts et catégories sont cohérents entre les différentes entités
4. Les balances sont calculées et mises à jour correctement

