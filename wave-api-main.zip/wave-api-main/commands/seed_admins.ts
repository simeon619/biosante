import { BaseCommand } from '@adonisjs/core/ace'
import User from '#models/user'
import Wallet from '#models/wallet'
import { BaseModel } from '@adonisjs/lucid/orm'

export default class SeedAdmins extends BaseCommand {
  public static commandName = 'seed:admins'
  public static description = 'Crée les 3 admins avec leurs wallets principaux'

  public static options = {
    startApp: true,
  }

  public async run() {
    this.logger.info('🌱 Création des admins...')

    const admins = [
      { email: 'sublymus@gmail.com', name: 'Admin Sublymus', website: 'https://sublymus.com', phone: '+225 0759020515' },
      { email: 'sablymus@gmail.com', name: 'Admin Sablymus', website: 'https://sablymus.com', phone: '+225 0759020516' },
      { email: 'seblymus@gmail.com', name: 'Admin Seblymus', website: 'https://seblymus.com', phone: '+225 0759020517' },
    ]

    const adminPassword = 'admin123' // À changer en production

    for (const adminData of admins) {
      // Vérifier si l'admin existe déjà
      const existingAdmin = await (User as typeof BaseModel)
        .query()
        .where('email', adminData.email)
        .first() as any

      if (existingAdmin) {
        this.logger.info(`⚠️  Admin ${adminData.email} existe déjà, mise à jour...`)
        existingAdmin.password = adminPassword
        existingAdmin.isActive = true
        existingAdmin.website = adminData.website

        // Vérifier si le wallet principal existe
        if (!existingAdmin.mainWalletId) {
          const platformWallet = new Wallet()
          platformWallet.managerId = existingAdmin.id
          platformWallet.ownerId = existingAdmin.id
          platformWallet.ownerName = existingAdmin.name
          platformWallet.ownerWavePhone = adminData.phone
          platformWallet.entityType = 'PLATFORM'
          // Note: balanceAccounting et balanceAvailable sont maintenant calculés dynamiquement
          ;(platformWallet as any)._balanceAccounting = 0
          ;(platformWallet as any)._balanceAvailable = 0
          platformWallet.overdraftLimit = 1000000000
          platformWallet.currency = 'XOF'
          platformWallet.isLocked = false
          await (platformWallet as any).save()
          await platformWallet.calculateBalanceAccounting()
          await platformWallet.calculateBalanceAvailable()

          existingAdmin.mainWalletId = platformWallet.id
          this.logger.success(`  ✅ Wallet principal créé: ${platformWallet.id}`)
        }

        await existingAdmin.save()
        this.logger.success(`✅ Admin ${adminData.email} mis à jour`)
        continue
      }

      // Créer l'admin
      const admin = new User()
      admin.name = adminData.name
      admin.email = adminData.email
      admin.password = adminPassword
      admin.apiKeyHash = null
      admin.isActive = true
      admin.webhookUrl = null
      admin.website = adminData.website
      await (admin as any).save()

      // Créer le wallet principal
      const platformWallet = new Wallet()
      platformWallet.managerId = admin.id
      platformWallet.ownerId = admin.id
      platformWallet.ownerName = admin.name
      platformWallet.ownerWavePhone = adminData.phone
      platformWallet.entityType = 'PLATFORM'
      // Note: balanceAccounting et balanceAvailable sont maintenant calculés dynamiquement
      ;(platformWallet as any)._balanceAccounting = 0
      ;(platformWallet as any)._balanceAvailable = 0
      platformWallet.overdraftLimit = 1000000000
      platformWallet.currency = 'XOF'
      platformWallet.isLocked = false
      await (platformWallet as any).save()
      await platformWallet.calculateBalanceAccounting()
      await platformWallet.calculateBalanceAvailable()

      // Lier le wallet à l'admin
      admin.mainWalletId = platformWallet.id
      await (admin as any).save()

      this.logger.success(`✅ Admin créé: ${adminData.email}`)
      this.logger.info(`   User ID: ${admin.id}`)
      this.logger.info(`   Wallet ID: ${platformWallet.id}`)
    }

    this.logger.success('🎉 Tous les admins ont été créés/mis à jour')
    this.logger.info('⚠️  Changez les mots de passe en production !')
  }
}

