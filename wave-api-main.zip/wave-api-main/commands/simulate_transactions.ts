import { BaseCommand } from '@adonisjs/core/ace'
import User from '#models/user'
import PaymentIntent from '#models/payment_intent'
import LedgerEntry from '#models/ledger_entry'
import WebhookEvent from '#models/webhook_event'
import { DateTime } from 'luxon'

const STATUSES: Array<'PENDING' | 'WAVE_CREATED' | 'COMPLETED' | 'FAILED'> = ['PENDING', 'WAVE_CREATED', 'COMPLETED', 'FAILED']
const WEBHOOK_STATUSES: Array<'PENDING' | 'PROCESSED' | 'FAILED' | 'IGNORED'> = ['PENDING', 'PROCESSED', 'FAILED', 'IGNORED']
const WEBHOOK_TYPES = ['checkout.session.completed', 'checkout.session.payment_failed']

const randomInt = (min: number, max: number) => Math.floor(Math.random() * (max - min + 1)) + min
const randomItem = <T>(array: T[]): T => array[Math.floor(Math.random() * array.length)] as T
const randomAmount = () => Math.floor(Math.random() * 300000);

export default class SimulateTransactions extends BaseCommand {
  public static commandName = 'simulate:transactions'
  public static description = 'Simule des transactions pour tous les admins (30-50 transactions sur 60 jours)'

  public static options = {
    startApp: true,
  }

  public async run() {
    this.logger.info('🎲 Simulation des transactions...')

    // Récupérer tous les admins
    const admins = await User
      .query()
      .whereIn('email', ['sublymus@gmail.com', 'sablymus@gmail.com', 'seblymus@gmail.com'])
      .preload('mainWallet')

    if (admins.length === 0) {
      this.logger.error('❌ Aucun admin trouvé. Exécutez d\'abord: node ace seed:admins')
      return
    }

    this.logger.info(`📊 ${admins.length} admin(s) trouvé(s)`)

    // Période : 60 derniers jours
    const endDate = DateTime.now()
    const startDate = endDate.minus({ days: 60 })

    for (const admin of admins) {
      if (!admin.mainWallet) {
        this.logger.info(`⚠️  Admin ${admin.email} n'a pas de wallet principal, ignoré`)
        continue
      }

      const wallet = admin.mainWallet
      const transactionCount = randomInt(30, 50)
      this.logger.info(`\n👤 ${admin.name} (${admin.email})`)
      this.logger.info(`   Wallet: ${wallet.id}`)
      this.logger.info(`   Transactions: ${transactionCount}`)

      // Note: Les soldes sont maintenant calculés dynamiquement depuis les ledger entries
      // On ne maintient plus de variables locales pour les soldes

      for (let i = 0; i < transactionCount; i++) {
        // Afficher la progression tous les 10 éléments
        if (i > 0 && i % 10 === 0) {
          this.logger.info(`   ⏳ Progression: ${i}/${transactionCount} transactions...`)
        }

        // Date aléatoire dans les 60 derniers jours
        const daysAgo = randomInt(0, 60)
        const createdAt = startDate.plus({ days: daysAgo }).plus({ hours: randomInt(0, 23), minutes: randomInt(0, 59) })

        // Générer un ID de transaction group cohérent basé sur les vrais IDs
        const transactionGroupId = `txn_${admin.id.slice(-8)}_${wallet.id.slice(-8)}_${i}`

        // Créer un Payment Intent
        const intentStatus = randomItem(STATUSES)
        const intent = new PaymentIntent()
        intent.externalReference = `ext_${createdAt.toMillis()}_${i}`
        intent.sourceSystem = 'SIMULATOR'
        intent.amount = randomAmount()
        intent.currency = 'XOF'
        intent.payerId = wallet.id
        intent.description = `Transaction simulée ${i + 1}`
        intent.aggregatedMerchantId = null
        intent.waveSessionId = intentStatus !== 'PENDING' ? `wave_${createdAt.toMillis()}` : null
        intent.waveCheckoutUrl = intentStatus === 'WAVE_CREATED' || intentStatus === 'COMPLETED' ? `https://checkout.wave.com/${intent.waveSessionId}` : null
        intent.status = intentStatus
        intent.splitsConfig = []
        ;(intent as any).createdAt = createdAt
        ;(intent as any).updatedAt = createdAt
        await (intent as any).save()

        // Créer un Webhook Event si le statut n'est pas PENDING
        if (intentStatus !== 'PENDING') {
          const webhookStatus: 'PENDING' | 'PROCESSED' | 'FAILED' | 'IGNORED' = intentStatus === 'COMPLETED' ? 'PROCESSED' : intentStatus === 'FAILED' ? 'FAILED' : randomItem(WEBHOOK_STATUSES)
          const webhook = new WebhookEvent()
          webhook.waveEventId = `evt_${createdAt.toMillis()}_${i}`
          webhook.type = randomItem(WEBHOOK_TYPES)
          webhook.payload = {
            payment_intent_id: intent.id,
            session_id: intent.waveSessionId,
            amount: intent.amount,
            status: intentStatus,
            timestamp: createdAt.toISO(),
          }
          webhook.status = webhookStatus
          webhook.processingError = webhookStatus === 'FAILED' ? 'Simulated error' : null
          ;(webhook as any).createdAt = createdAt
          ;(webhook as any).updatedAt = createdAt
          await (webhook as any).save()
        }

        // Créer des Ledger Entries si la transaction est complétée
        if (intentStatus === 'COMPLETED') {
          // Décider aléatoirement si c'est un CREDIT ou DEBIT (50/50)
          const isCredit = Math.random() > 0.5
          
          // Catégories pour crédits (entrées)
          const creditCategories: Array<'ORDER_PAYMENT' | 'SERVICE_PAYMENT' | 'COMMISSION' | 'DEPOSIT' | 'SUBSCRIPTION'> = ['ORDER_PAYMENT', 'SERVICE_PAYMENT', 'COMMISSION', 'DEPOSIT', 'SUBSCRIPTION']
          // Catégories pour débits (sorties)
          const debitCategories: Array<'PAYOUT' | 'REFUND' | 'ADJUSTMENT'> = ['PAYOUT', 'REFUND', 'ADJUSTMENT']
          
          const direction: 'CREDIT' | 'DEBIT' = isCredit ? 'CREDIT' : 'DEBIT'
          const category = isCredit ? randomItem(creditCategories) : randomItem(debitCategories)
          
          // Pour les CREDIT, utiliser le montant de l'intent
          // Pour les DEBIT, utiliser un montant aléatoire (généralement 60-90% du montant intent pour réalisme)
          const amount = direction === 'CREDIT' 
            ? intent.amount 
            : intent.amount * 0.5 // Si le calcul donne 0, utiliser un montant aléatoire
          
          const fundsStatusOptions: Array<'ON_HOLD' | 'AVAILABLE'> = ['ON_HOLD', 'AVAILABLE']
          const fundsStatus: 'ON_HOLD' | 'AVAILABLE' | 'LOCKED' | 'FAILED' | 'CANCELED' | 'REFUNDED' = 
            (category === 'ORDER_PAYMENT' || category === 'SERVICE_PAYMENT') && direction === 'CREDIT' 
              ? randomItem(fundsStatusOptions) 
              : 'AVAILABLE'

          // Entry CREDIT (entrant)
          if (direction === 'CREDIT') {
            // Note: Les soldes sont maintenant calculés dynamiquement depuis les ledger entries
            const creditEntry = new LedgerEntry()
            creditEntry.walletId = wallet.id
            creditEntry.transactionGroupId = transactionGroupId
            creditEntry.amount = amount
            creditEntry.direction = 'CREDIT'
            creditEntry.category = category
            creditEntry.label = `Paiement ${category} - ${intent.description}`
            creditEntry.sourceSystem = 'SIMULATOR'
            creditEntry.externalReference = intent.externalReference
            creditEntry.metadata = { intent_id: intent.id, webhook_id: intent.waveSessionId }
            creditEntry.fundsStatus = fundsStatus
            creditEntry.releaseScheduledAt = fundsStatus === 'ON_HOLD' ? createdAt.plus({ hours: 24 }) : null
            creditEntry.releasedAt = fundsStatus === 'AVAILABLE' ? createdAt : null
            ;(creditEntry as any).createdAt = createdAt
            ;(creditEntry as any).updatedAt = createdAt
            await (creditEntry as any).save()
          } else {
            // Entry DEBIT (sortant) - utiliser un montant aléatoire
            const debitAmount = randomAmount() // Montant aléatoire pour les sorties
            
            // Vérifier le solde disponible avant de créer le débit
            // Note: Les soldes sont maintenant calculés dynamiquement depuis les ledger entries
            const currentBalance = await wallet.calculateBalanceAvailable()
            if (currentBalance >= debitAmount) {
              const debitEntry = new LedgerEntry()
              debitEntry.walletId = wallet.id
              debitEntry.transactionGroupId = transactionGroupId
              debitEntry.amount = debitAmount
              debitEntry.direction = 'DEBIT'
              debitEntry.category = category
              debitEntry.label = `Retrait ${category} - ${intent.description}`
              debitEntry.sourceSystem = 'SIMULATOR'
              debitEntry.externalReference = intent.externalReference
              debitEntry.metadata = { intent_id: intent.id }
              debitEntry.fundsStatus = 'AVAILABLE'
              debitEntry.releaseScheduledAt = null
              debitEntry.releasedAt = null
              ;(debitEntry as any).createdAt = createdAt
              ;(debitEntry as any).updatedAt = createdAt
              await (debitEntry as any).save()
            }
          }
        }
      }

      // Calculer les soldes depuis les ledger entries créées
      // Note: Les soldes sont maintenant calculés dynamiquement depuis les ledger entries
      const finalBalanceAccounting = await wallet.calculateBalanceAccounting()
      const finalBalanceAvailable = await wallet.calculateBalanceAvailable()

      this.logger.success(`   ✅ Solde comptable: ${finalBalanceAccounting.toLocaleString('fr-FR')} XOF`)
      this.logger.success(`   ✅ Solde disponible: ${finalBalanceAvailable.toLocaleString('fr-FR')} XOF`)
    }

    this.logger.success('\n🎉 Simulation terminée avec succès !')
  }
}

