import { BaseCommand } from '@adonisjs/core/ace'
import { CommandOptions } from '@adonisjs/core/types/ace'
import releaseService from '#services/release_service'

export default class ReleaseHolds extends BaseCommand {
  static commandName = 'release:holds'
  static description = 'Libère automatiquement les fonds ON_HOLD dont le délai est expiré (LOCKED gérés par le système)'

  static options: CommandOptions = {
    startApp: true,
  }

  async run() {
    this.logger.info('Starting release of expired holds...')

    try {
      const releasedCount = await releaseService.releaseExpiredHolds()
      this.logger.success(`Released ${releasedCount} expired hold(s)`)
      return releasedCount
    } catch (error: any) {
      this.logger.error(`Failed to release holds: ${error.message}`)
      throw error
    }
  }
}

